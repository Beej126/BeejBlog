---
title: Team Services Cheat Sheet
author: Beej
type: post
date: 2017-01-06T03:04:25+00:00
url: /2017/01/team-services-cheat-sheet.html
snap_isAutoPosted:
  - 1
snapEdIT:
  - 1
snapTW:
  - 's:181:"a:1:{i:0;a:7:{s:9:"timeToRun";s:0:"";s:10:"SNAPformat";s:19:"%TITLE% - %EXCERPT%";s:8:"attchImg";s:1:"1";s:9:"isAutoImg";s:1:"A";s:8:"imgToUse";s:0:"";s:4:"doTW";i:0;s:2:"do";i:0;}}";'
dsq_thread_id:
  - 5895426555
categories:
  - Uncategorized
tags:
  - VCS

---
## Visual Studio Team Services aka VSTS aka Visual Studio Online aka VSO

### uppermost administrative user bucket

![image][1]

 [1]: https://cloud.githubusercontent.com/assets/6301228/21706134/a3003a24-d379-11e6-9119-078812104661.png