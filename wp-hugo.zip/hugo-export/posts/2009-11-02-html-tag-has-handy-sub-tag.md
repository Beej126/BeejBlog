---
title: 'HTML <Table> tag has a handy <Caption> sub-tag'
author: Beej
type: post
date: 2009-11-02T17:02:00+00:00
url: /2009/11/html-tag-has-handy-sub-tag.html
blogger_bid:
  - 7726907200224433699
blogger_blog:
  - www.beejblog.com
blogger_id:
  - 7300415393535526187
blogger_author:
  - g108669953529091704409
blogger_permalink:
  - /2009/11/html-tag-has-handy-sub-tag.html
categories:
  - Uncategorized
tags:
  - WebDev

---
(again, who knew?!) 

  * Found it here under “<a href="http://puzzling.org/computing/help/html/inline" target="_blank">Photo Albums that Wrap</a>”.
  * Coupled with the “display: inline” style on the table…
  * it winds up being the perfect answer for showing nicely wrapped <a href="/2009/11/good-movies.html" target="_blank">DVD covers</a> (basically the same as a photo album).
  * Don’t miss the Align attribute to place it either above or below the table.
  * I’m sure this will come in handy in many places requiring a well contained but still wrappable block.