---
title: Roof Cargo Box
author: Beej
type: post
date: 2013-05-01T22:27:00+00:00
url: /2013/05/roof-cargo-box.html
blogger_bid:
  - 7726907200224433699
blogger_blog:
  - www.beejblog.com
blogger_id:
  - 7528222115032473257
blogger_author:
  - g108669953529091704409
blogger_permalink:
  - /2013/05/roof-cargo-box.html
blogger_thumbnail:
  - http://lh6.ggpht.com/-zUTVJtFe3sE/UZwQMBZJtII/AAAAAAAAFTM/cJyifG1u-Fo/image%25255B26%25255D.png?imgmax=800
snapEdIT:
  - 1
snapTW:
  - |
    s:174:"a:1:{i:0;a:6:{s:2:"do";s:1:"1";s:10:"SNAPformat";s:27:"%TITLE%
    %URL%
    
    %EXCERPT%";s:8:"attchImg";s:1:"1";s:9:"isAutoImg";s:1:"A";s:8:"imgToUse";s:0:"";s:4:"doTW";s:1:"1";}}";
dsq_thread_id:
  - 5516509213
categories:
  - Uncategorized
tags:
  - Hardware
  - Outdoors

---
<a title="yeah, i know, really poor iphone photo :(" href="http://www.pepboys.com/product/details/9511536/00528/" target="_blank"><img title="yeah, i know, really poor iphone photo :(" style="border-left-width: 0px; border-right-width: 0px; background-image: none; border-bottom-width: 0px; float: right; padding-top: 0px; padding-left: 0px; margin: 0px 0px 0px 10px; display: inline; padding-right: 0px; border-top-width: 0px" border="0" alt="yeah, i know, really poor iphone photo :(" align="right" src="http://lh6.ggpht.com/-zUTVJtFe3sE/UZwQMBZJtII/AAAAAAAAFTM/cJyifG1u-Fo/image%25255B26%25255D.png?imgmax=800" width="434" height="348" /></a>Installed this last night&#8230; found in local <a href="http://www.pepboys.com/product/details/9511536/00528/" target="_blank">Pep Boys</a> inventory… blasted them with a $20 coupon that expired that day 🙂 so was out the door at $210 + tax.

This PepBoys SKU is barely a rebrand of the SportRack “Voyager XL”… the manual inside is OEM, headered with “90274 Voyager XL” and “A90275 Aero XL”… one forum I read said this bugger gets down around $100 sometimes during PepBoys promos… something to keep an eye on. Dimensions: 35 pounds (doesn’t feel like it), 18 cubic feet (this is the max end of the range from what I could see), 62 x 39.5 x 19 inches. We have a “mountain buggy” stroller & kiddie trailer that are in the 31” width, 45” length, 15” height (when flat) range so this opens the possibility of tossing up there if we want to suffer the inconvenience – more likely for a longer trip with a nice long usage window between load and unload. Caveat: The lid “spring lift” hinges are mostly plastic. They feel pretty fragile. I expect to break them eventually (vacation stress induced daddy hulk-out moment ).&nbsp; I feel this is the primary sacrifice vs more expensive, beefier models. I look at it as a convenience for as long as it lasts and the box should still be functional after that, simply requiring manual prop open. 

Note: <a href="http://www.thule.com/en-us/ca/about-thule/about-the-brand" target="_blank">SportRack is a Thule acquisition circa 2005</a>. 

This same basic model goes for a big range of prices under different names:

  * over <a href="http://www.amazon.com/gp/offer-listing/B000UULZO0/ref=dp_olp_new?ie=UTF8&condition=new" target="_blank">$500</a> as the A90275 Aero XL on Amazon for no good reason. 
      * Or only <a href="http://www.amazon.com/SportRack-SR7018-Vista-Opening-18-Cubic/dp/B00BCLL8C0/ref=dp_ob_title_sports" target="_blank">$280</a> as the SR7018 Vista XL. 
          * Walmart carries it as Aero XL for <a href="http://www.walmart.com/ip/SportRack-Aero-XL-Roof-Box-Model-A90275/15611297" target="_blank">$300</a> and <a href="http://www.walmart.com/ip/Auto-Rooftop-Cargo-Boxes-Your-Choice/22218859?findingMethod=rr" target="_blank">$250</a>, take your pick haha. </ul> 
        <a title="quick release kit" href="http://www.etrailer.com/Accessories-and-Parts/SportRack/SR04952.html?feed=npn&gclid=CP2cgsf-9bYCFeFxQgodZVUA2g" target="_blank"><img title="quick release kit" style="border-left-width: 0px; border-right-width: 0px; background-image: none; border-bottom-width: 0px; float: right; padding-top: 0px; padding-left: 0px; margin: 0px 0px 0px 10px; display: inline; padding-right: 0px; border-top-width: 0px" border="0" alt="quick release kit" align="right" src="http://lh4.ggpht.com/-GltWs7E7U1o/UZwQMkklYBI/AAAAAAAAFTQ/Qjq_0mjeZ-M/image%25255B27%25255D.png?imgmax=800" width="246" height="132" /></a>It was very straightforward to install… a few casual minutes, very doable by one person as long as you can lift it up there. The u-bolts are simple and practical… I am however hoping this <a href="http://www.etrailer.com/Accessories-and-Parts/SportRack/SR04952.html?feed=npn&gclid=CP2cgsf-9bYCFeFxQgodZVUA2g" target="_blank">$30 quick release kit</a> will let me pop it on/off a little faster so we can garage the SUV w/o hassle… will report back on that. [Update 2013-08-02] Ok I can now recommend the quick release kit. It’s not what I would call nirvana but it’s definitely more convenient than the stock brackets. They’re just as sturdy as stock bracket when tightened down, no concern of slippage. If you look at the picture to the right, with the metal plates numbered 1,2,3 from top to bottom – ones roof rack cross bars fit between plates 2 & 3. The “quick” part of this is that one bolt always remains connected to plate 3 and one bolt is free, creating an opening for the cross bar insertion and subsequent removal. Simply because one bolt stays connected, the hardware is always attached to the cargo box and more ready to go, unlike the stock u-bolts which must be completely separated from their nuts to remove the cargo box from the roof. Hopefully that makes sense enough to satisfy your purchase anxiety. It’s pretty obvious what has to happen when you get it in front of you.
        
        Lastly, the one other tempting unit I saw out there in this bargain range is the <a href="http://www.sears.com/x-cargo-sport-20-car-top-carrier/p-02872030000P?prdNo=1&blockNo=1&blockType=G1" target="_blank">X-Cargo Sport 20 currently for $180 at Sears</a>. It wasn’t stocked locally for me at the time, and Sears’ shopping cart indicated $90 to do the oversized shipping. This unit is worthy of consideration based on size and price. 20 cubic feet is the biggest I’ve seen. 67.5 x 36.25 x 20.25 inches, same 35 lbs. Follow-up after 3 months usage – We’ve been very satisfied with the size and performance. No recognizable wind resistance driving impacts. The rather prominent Pep Boys decal on the back face peels right off if that doesn’t fit your vanity profile 🙂