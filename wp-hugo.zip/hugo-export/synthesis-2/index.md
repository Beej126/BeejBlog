---
title: Synthesis
author: admin
type: page
date: 2016-03-04T22:57:01+00:00

---
<div class="lr_dct_ent" data-hveid="28">
  <div>
    <div class="lr_dct_ent_ph">
      <span class="lr_dct_ph"><span>ˈsinTHəsəs</span>/</span>
    </div>
    
    <div>
      <div class="lr_dct_sf_h">
        <i><span>noun</span></i>
      </div>
      
      <ol class="lr_dct_sf_sens">
        <li>
          <div>
            <div class="lr_dct_sf_sen vk_txt">
              <div style="margin-left:20px">
                <div style="margin-left:-20px" class="_Jig">
                  <div style="display:inline" data-dobid="dfn">
                    <span>combination or composition, in particular.</span>
                  </div>
                </div>
                
                <div style="margin-left:-32px">
                  <ul>
                    <li>
                      <div class="lr_dct_sf_subsen">
                        <div class="_Jig">
                          <div style="display:inline" data-dobid="dfn">
                            <span>the combination of ideas to form a theory or system.</span>
                          </div>
                          
                          <div class="vk_gy">
                            <span>noun: <b>synthesis</b></span><span>; plural noun: <b>syntheses</b></span>
                          </div>
                          
                          <p>
                            <span></p> 
                            
                            <div class="vk_gy">
                              &#8220;the synthesis of intellect and emotion in his work&#8221;
                            </div>
                            
                            <p>
                              </span>
                            </p>
                            
                            <div>
                              <table class="vk_tbl vk_gy">
                                <tr style="background-colors: white;">
                                  <td class="lr_dct_nyms_ttl" style="padding-right:3px">
                                    synonyms:
                                  </td>
                                  
                                  <td>
                                    <span><a href="//www.google.com/search?espv=2&biw=1920&bih=1075&q=define+combination&sa=X&ved=0ahUKEwiTvcWSnMbMAhVO9GMKHUdZDJAQ_SoIHzAA" data-ved="0ahUKEwiTvcWSnMbMAhVO9GMKHUdZDJAQ_SoIHzAA">combination</a>, </span><span><a href="//www.google.com/search?espv=2&biw=1920&bih=1075&q=define+union&sa=X&ved=0ahUKEwiTvcWSnMbMAhVO9GMKHUdZDJAQ_SoIIDAA" data-ved="0ahUKEwiTvcWSnMbMAhVO9GMKHUdZDJAQ_SoIIDAA">union</a>, </span><span><a href="//www.google.com/search?espv=2&biw=1920&bih=1075&q=define+amalgam&sa=X&ved=0ahUKEwiTvcWSnMbMAhVO9GMKHUdZDJAQ_SoIITAA" data-ved="0ahUKEwiTvcWSnMbMAhVO9GMKHUdZDJAQ_SoIITAA">amalgam</a>, </span><span><a href="//www.google.com/search?espv=2&biw=1920&bih=1075&q=define+blend&sa=X&ved=0ahUKEwiTvcWSnMbMAhVO9GMKHUdZDJAQ_SoIIjAA" data-ved="0ahUKEwiTvcWSnMbMAhVO9GMKHUdZDJAQ_SoIIjAA">blend</a>, </span><span><a href="//www.google.com/search?espv=2&biw=1920&bih=1075&q=define+mixture&sa=X&ved=0ahUKEwiTvcWSnMbMAhVO9GMKHUdZDJAQ_SoIIzAA" data-ved="0ahUKEwiTvcWSnMbMAhVO9GMKHUdZDJAQ_SoIIzAA">mixture</a>, </span><span><a href="//www.google.com/search?espv=2&biw=1920&bih=1075&q=define+compound&sa=X&ved=0ahUKEwiTvcWSnMbMAhVO9GMKHUdZDJAQ_SoIJDAA" data-ved="0ahUKEwiTvcWSnMbMAhVO9GMKHUdZDJAQ_SoIJDAA">compound</a>, </span><span><a href="//www.google.com/search?espv=2&biw=1920&bih=1075&q=define+fusion&sa=X&ved=0ahUKEwiTvcWSnMbMAhVO9GMKHUdZDJAQ_SoIJTAA" data-ved="0ahUKEwiTvcWSnMbMAhVO9GMKHUdZDJAQ_SoIJTAA">fusion</a>, </span><span><a href="//www.google.com/search?espv=2&biw=1920&bih=1075&q=define+composite&sa=X&ved=0ahUKEwiTvcWSnMbMAhVO9GMKHUdZDJAQ_SoIJjAA" data-ved="0ahUKEwiTvcWSnMbMAhVO9GMKHUdZDJAQ_SoIJjAA">composite</a>, </span><span><a href="//www.google.com/search?espv=2&biw=1920&bih=1075&q=define+alloy&sa=X&ved=0ahUKEwiTvcWSnMbMAhVO9GMKHUdZDJAQ_SoIJzAA" data-ved="0ahUKEwiTvcWSnMbMAhVO9GMKHUdZDJAQ_SoIJzAA">alloy</a></span><span>;</span><span> </span><span data-log-string="synonyms-more-click" jsaction="dob.m"><span class="lr_dct_more_btn" style="padding-left: 4px; display: none;">More</span></p> 
                                    
                                    <div style="display:inline">
                                      <div style="display:inline">
                                        <div class="lr_dct_more_txt xpdxpnd xpdnoxpnd" data-mh="0" style="max-height: none; display: inline;" data-mhc="1">
                                          <span><a href="//www.google.com/search?espv=2&biw=1920&bih=1075&q=define+unification&sa=X&ved=0ahUKEwiTvcWSnMbMAhVO9GMKHUdZDJAQ_SoIKTAA" data-ved="0ahUKEwiTvcWSnMbMAhVO9GMKHUdZDJAQ_SoIKTAA">unification</a>, </span><span><a href="//www.google.com/search?espv=2&biw=1920&bih=1075&q=define+amalgamation&sa=X&ved=0ahUKEwiTvcWSnMbMAhVO9GMKHUdZDJAQ_SoIKjAA" data-ved="0ahUKEwiTvcWSnMbMAhVO9GMKHUdZDJAQ_SoIKjAA">amalgamation</a>, </span><span><a href="//www.google.com/search?espv=2&biw=1920&bih=1075&q=define+marrying&sa=X&ved=0ahUKEwiTvcWSnMbMAhVO9GMKHUdZDJAQ_SoIKzAA" data-ved="0ahUKEwiTvcWSnMbMAhVO9GMKHUdZDJAQ_SoIKzAA">marrying</a></span><span> </span>
                                        </div>
                                        
                                        <div class="lr_dct_more_txt xpdxpnd xpdnoxpnd" data-mh="0" style="max-height: none; display: inline;" data-mhc="1">
                                          <span></p> 
                                          
                                          <div class="vk_gy">
                                            &#8220;the synthesis of their diverse styles makes for a wonderful new sound in country music&#8221;
                                          </div>
                                          
                                          <p>
                                            </span></div> </div> </div> 
                                            
                                            <p>
                                              </span></td> </tr> </tbody> </table> </div> </div> </div> </li> </ul> </div> </div> </div> </div> </li> </ol> </div> </div> 
                                              
                                              <div class="xpdxpnd" data-mh="137" data-mhc="1" style="max-height: 137px;">
                                                <div class="vk_sh vk_gy" style="margin:20px 0 0">
                                                  Origin
                                                </div>
                                                
                                                <div>
                                                  <img style="margin:10px 0 12px;max-width:100%;border:0;height:59px;width:367px" height="59" id="lr_dct_img_origin_synthesis0" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAW8AAAA7CAYAAAC0VAtBAAAN4ElEQVR42u2d93MUyRXH9feY32xjG1Pm7jgEBuRDAkQ4wHAkoyMdoe4IxhSHcMmGgyNjchAiCEwWOSMyR85Fzjnn8OxvV72t3mZndlagDaPvp2pqdyd097zp+fbr17M9WacfiHCp+JIKaNOqbVNCQBYFmEJDm9I+hOJN8abQ0KYUb0Lx5o1E8aZNKd6E4k2hoU0p3oTizYVCQ5tSvEkoxPvY7dfy48gJkte8leTmt5TcZl9Lvx//LesPnI3a7/d/rCmNmraILDmN86VLrx+k/PRNz310mb54TaDtX9Zr8EH5Zi/fKA0aNY7KJ2xCE4ZrkC42jVV+d+kzqFBq1/1z5Hf5qRtRtvhVtWpRv7HdTvfXv60uUxauSihvQj6peJ+4+1Yat2gtP00ullP335t1R2+9knmrt0t2/Rz55fJj34o5qWSZ9P770MA3TqLbx8xYYMpnlyNs4h2Wa5Ap4n3kxgvTOBb07ielG3YHTsNe96fPaxvx33v+HsWbpEa8i8ZNkw7ffhdzW/GKzTJu9iLfinn4+nOpl9OoUoRj8PCx8tfOXeXY/4UszF38sFyDTBFvNEZjZ5VK2e7j0v7bnhUSb3yftmi1tOvSneJNUiPe8KhKyrYF2tetmEdvvpRBRT+b5VMKx8l776T794Pkm4Ie5nvY47NhuQaZIt75rdoau+E7PHDXew4q3viEeEPEKd4k6eL92ZfZJt6qv5dsORAV66v/VZ5nLBW/m7RsE3W8VzxVu9zxtn+RXU/adCwwwoGu6a6zt0Mv3mG5Bpkg3ku3/iIDCkdEfk8sWSqFP/+nwuIN4bfDJxRvklTPG7HVWNs2Hb4gv6n+O88KffzOG9Pl7/HDPz6Z11f9DzVMl1ZjuQ1zm4Q+bBKWa5AJ4t2pex/TGGqD9ZfGzUxjpWMNiYo3lqmlZaaHQvEmSRXvf42fLh269oq57fshRWZU3a9CY7AN3lllDZb1HzpcOvfoG2rxDss1SHfxhnec37rdB+t79hss89fsqLB4Y2n7t27maR2KN0maeOuTDiOnzI14H/suPjC/4aXAK4l3U9SuW7/ShANl+vqbzvLPMVNC/7RJpl+DdBfvoSMnmsFKd/2ybQdNmOhjxHvPubvmOtmNKMWbVKp46zPGQ34abwZvvmrS3Dy5gEfPMKjjV2HtASA8fuUXT51Q/N9A22PlcfDqU/PIHJ68CPNz3pl+DdLFpjg/PP9uLw3zmkrNz76QA5cfxTzm8zp1o2L7iYo3Fjz3bfeSKN6k0sWb/7BMvXjTpuG3KSEUbwoNbUrxJhRvijeFhjaleBOKN28kijdtSvEmFG8KDW1K8SahEm+agBBCKN6EEEIo3oQQQijehBBC8SaEEELxJoQQQvEmhBCKNyGEEIo3IYSQDBXvBg0aeP7225aq8iWLV69epbRCVLbtU2VXkjpSVafDXpfTRryvXLmSVuJtlyeZXLhwIaUCXtm2T5VdSepIVZ0Oe12OK94nT56Url27SsuWLaWgoEDOnDnjaQjXey4vL5f27dtLfn6+9O/f35zs48ePpUWLFlKtWjXzeejQocj+fttipQXev38vGzdulE6dOkn9+vVl9OjRZl284+7evStDhgyRdu3ambz69u0r58+fT3mreu7cuUCVPZnXpSK2D1I+r31IuPiYOt20aVNzryovXryQvLw81uUg4o0T1RM8ePCg9OrVK5BI1KpVS0aMGBExwMKFC6WwsLBCYRO/tDZv3izdunWTJ0+eyPPnz2XgwIGyffv2uMcVFRVJWVlZJI8DBw5I796900K8g1T2ZF2Xito+SPm89iHhE++K1ulZs2bJ7NmzI/usXr1axo8fz7ocRLx79uwpS5YskXfv3kV1FeKJRI0aNeTp06dRca+gcW13m19aMLLdyqF8ekH8jtu7d29UHidOnJCaNWvGFe/79+9X6qIVPV5lT9Z1qajtg5TPa59k2pvL/bSu0/fu3TPes73PpUuXMrIuJ128cbJTpkwx3Yk+ffrI1atXPUUiOzvbV/wqKt5+aeETF9deOnToEPe4W7duyaBBg6RLly7G4544cWLc8tteRLIWrajpcF0SsX2Q8nntk0p7c0m/Ot25c2e5fPmyvHz5Ulq3bp2xdTmp4o2WaevWrZHfR44ckY4dO5rvDRs2lLdv30a2HTt2TKpXr5508R4wYECUodAl2r9/f9zj+vXrJ7t3746sf/jwoelWZYLnnarrEtT2fuXTY/32oedd9Txvv/qA8Oa4ceNk7dq1Mn369Iyty0n3vJs3by7Xrl2LhBYQlAeDBw+WVatWme/o2uDk69SpE9iwGBTQ2FMi29x1GGSAB404FcDF1RiZ33FoVXE+4NGjR6b8QcIm6RIfTMV1ScT2XuWz0/Pah1TNmLdXfcAxGLiER3vz5k3W5aDijdYH3RaMoqJAuAgAFwJPaDRq1Mh0ZRBDtmNT8Qw7fPhwadOmjWmlEtnmpgUvc+XKlUaMW7VqJcOGDZM3b97EPQ4eKVrHZs2aSU5OjqxZs8bEvcaMGZNy8Q4yMp+K65KI7b3KZ6fntQ8Jn3h/TJ1Wz7ht27aBPemqUJf5D8s0I9XPeROSjnV6zpw5UlJSQmNSvNMXCjdhnY4GoQ/0HjEuRSjehJAMAP+/yM3NleLiYhqD4k0IIRRvQgghFG9CCCEUb0IIoXgTQgiheBNCCKk88Z42bVpSClLZ+bjpJ+u8CCHRYGKq9evXJ3zc69evZcGCBXL69OnIuqNHj5rHCO1l1KhRkbn57fsc+W7YsCGl5/4pdYfiTQhJKjt37jQvLwgKZhPEpFT4hyVekmBP6+qCyaV0nn78qQdzdtv5njp1KmXn7Zbnk4g3WivMZYuJWObNm2cmVtEJXVTknj17JuvWrTMtH/ZfsWKFmfhIwZSNS5culblz55oJ09XAZ8+eldLSUpk6dWpkcnP3wiA9TJKOz+vXr5v1N27cMOlgHT7xW0GaMAImasd3W4jd/LzSxzEXL14054PzxgW3/8HlVW4ch3PF33VtD4CQsIM31CxatEhmzpxp7j97/o7bt2/LsmXLzD0GDbHnxobo4jc+Mc8I7iv8+cbVg/nz50dpioJ/aKqe+Dld2AflwpwkeHvOpEmTzIJyAeSLexb3PM4BL2DwAhNU4Tjc59j/8OHDgewATYKH7+YRqzwzZsyImgEUx0FjXZth3qVYtjLiPXnyZNm0aZMxEsRu+fLlEWFSY2G73VqihcN+AIKIwmJ2PoD9UAicFCYoR7ro8kCE7VeNeXnCeO0RjHbnzh3zGzOJQWCxHmni5PE6JCwQ3QkTJpj9/PJzLzqOsadxxMXRLpVfOjA+fuMCElJVgDMHRwYOj4obxEdfPgCRwfSvKrbQFAAhxZtvMP0y7iWAGftwb8PZU/DyAvvNVrHA/Y/7MhYoBwT1wYMHkXWYKdDWG5Rj27ZtRuMAHE17fwWCChHWKWKRNs4PeuNnB5wrQjYQbOzr5mGXBzZCHja7du0yE+a5NvOylRFvdEVUKFUsdVpRFT14mzZ4mQHm2AWIX7lvjsD+EDk7XXi2XjEnW1zRULgiD0GFUVwvHN9RfuCXnyveY8eOjZpzARdM9/FLB3nZ01ISUhXA/bxjx46odSpGuHfgeSsQcbyYAGCaVP2u2/SNMxA9BR5sPIcIXrv7BixbM9z3Rqrgar6YMVRnCgSYRdAut4I83Jg8egSIPvjZAefql4ddHtvLVhYvXmzycW3mZass9UJddGcVNLzbDe47MoDHjfiRtq7Y15431xZkdzDBK+Zjiyu6G9qi2+KKFtvNC9/1nXZ++QWJees6v3RsoxJSVUDMGZ6ifU/gPoFTBUcHIoXeNxZ4m/gNMFUq3umoYIBRBVjvZTh+EMB4QH9ivaEG2oSeugt0xM4XmuVuj6VbCK+4zmoQO+Bc/fKwy6NetgLBR68+ls28bJUVy5uEV+163nDT7dcXoQVR0Xc9b2SC1gkerDsTmNfrgVzPG9NIup43Gg6Uwy4rvtuet1d+iYh3IukQUhWAoMHztNHxIwiY7cHu2bMnEiPG2Bj0xBZgfWkBPHCEFHBf60sQ/ID42V6trRf6YhXbU9awruar5dWwBRqZWKABQoNgO44a1/azA87VKw+3PAiD2PF9jAHolLeuzbxsZcQb729EiwJBRoaxYt7wPDVB7AeB07CJG/NGq4HYEgb9YDSNde3bty/yijIXxJHs2BYqhIYuUDFgBHRN0DVC+RC3woJyaCPil5+dfjzx9kuH4k2qIvBcMWimXiQEGjFZ7RHretyriPuqVrg9ZQiwDtIhvS1btnwQhogFRNuNEQNoAO5t14OGmMO7VXCsPTiImLWXt4/BRT1XRAAQ3tDxPi87ANjBKw+3PHBCNW4Om6F8OrgZK5IRy1ZZKkgQLCQA9T9+/PgHT5vAw0Wrg+4JCglxh3BqYvDK0ZpAdBEf1uA+Cg3hR7o4ETccoqBgGKXWeLY+bYKBShyrj/jgeHQ3MNqKimA/beKXn5u+n3j7pUPxJlURODIQEH2aBIP9qhFw1nCfwsHCvYJtcLDgCNrhDKRh/8Y97Y49eYGevRsjBhDOWHFw3Oe4V3GMmy9AeMP11m2PGc6nPmlip+9lBxyjr02LlYddHhVsaBjSh+NcXl5u7OHazM9WWZkmSAhnqEcMdACEEJJZwJtFr5ZUzFYZJ97wtBHj0q4UWnr7GUxCSPqDECs8VzvMQBKzVcaJt8Z/cDLopqE1sj1xQkh6g3ACQq9eDy+QYLb6H57gQUx5j/ESAAAAAElFTkSuQmCC" width="367" aria-hidden="true" data-deferred="1" onload="google.aft&&google.aft(this)" />
                                                </div>
                                                
                                                <div>
                                                  <span>early 17th century: via Latin from Greek <i>sunthesis</i>, from <i>suntithenai</i> ‘place together.’</span>
                                                </div>
                                              </div></div> 
                                              
                                              <hr />
                                              
                                              <p>
                                                [add_posts tag=synthesis]
                                              </p>