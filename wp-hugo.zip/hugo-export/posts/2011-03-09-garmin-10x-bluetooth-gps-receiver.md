---
title: Garmin 10x Bluetooth GPS Receiver Broken Clip Hack
author: Beej
type: post
date: 2011-03-09T21:48:00+00:00
url: /2011/03/garmin-10x-bluetooth-gps-receiver.html
blogger_bid:
  - 7726907200224433699
blogger_blog:
  - www.beejblog.com
blogger_id:
  - 8924888960733598037
blogger_author:
  - g108669953529091704409
blogger_comments:
  - 1
blogger_permalink:
  - /2011/03/garmin-10x-bluetooth-gps-receiver.html
blogger_thumbnail:
  - http://lh3.ggpht.com/_XlySlDLkdOc/TXf1qsGV0sI/AAAAAAAAE5w/tNXeNmqnw0Y/image_thumb%5B7%5D.png?imgmax=800
dsq_thread_id:
  - 5508631630
snapEdIT:
  - 1
snapTW:
  - |
    s:199:"a:1:{i:0;a:7:{s:2:"do";s:1:"1";s:9:"msgFormat";s:27:"%TITLE%
    %URL%
    
    %EXCERPT%";s:8:"attchImg";s:1:"1";s:9:"isAutoImg";s:1:"A";s:8:"imgToUse";s:0:"";s:9:"isAutoURL";s:1:"A";s:8:"urlToUse";s:0:"";}}";
categories:
  - Uncategorized
tags:
  - Hardware

---
I really really dig how this popped together… reason, the stock Garmin plastic clip busted on me last saturday [<img style="background-image: none; border-right-width: 0px; padding-left: 0px; padding-right: 0px; display: inline; border-top-width: 0px; border-bottom-width: 0px; border-left-width: 0px; padding-top: 0px" title="image" border="0" alt="image" src="http://lh3.ggpht.com/_XlySlDLkdOc/TXf1qsGV0sI/AAAAAAAAE5w/tNXeNmqnw0Y/image_thumb%5B7%5D.png?imgmax=800" width="494" height="441" />][1][<img style="background-image: none; border-right-width: 0px; padding-left: 0px; padding-right: 0px; display: inline; border-top-width: 0px; border-bottom-width: 0px; border-left-width: 0px; padding-top: 0px" title="image" border="0" alt="image" src="http://lh3.ggpht.com/_XlySlDLkdOc/TXf1_RqiC2I/AAAAAAAAE6Q/RYcY7L3CEm4/image_thumb%5B11%5D.png?imgmax=800" width="574" height="440" />][2][<img style="background-image: none; border-bottom: 0px; border-left: 0px; padding-left: 0px; padding-right: 0px; display: inline; border-top: 0px; border-right: 0px; padding-top: 0px" title="DSCF5074 -notes" border="0" alt="DSCF5074 -notes" src="http://lh4.ggpht.com/_XlySlDLkdOc/TXkd2Vc5OZI/AAAAAAAAE6o/2BOfdvsVe3s/DSCF5074%20-notes_thumb%5B2%5D.jpg?imgmax=800" width="518" height="397" />][3][<img style="background-image: none; border-right-width: 0px; padding-left: 0px; padding-right: 0px; display: inline; border-top-width: 0px; border-bottom-width: 0px; border-left-width: 0px; padding-top: 0px" title="image" border="0" alt="image" src="http://lh5.ggpht.com/_XlySlDLkdOc/TXf1v_f-j5I/AAAAAAAAE6I/7e00gp1rLi0/image_thumb%5B8%5D.png?imgmax=800" width="605" height="397" />][4]

 [1]: http://lh5.ggpht.com/_XlySlDLkdOc/TXf1pVVg7WI/AAAAAAAAE5s/VoBs6dXwy-E/s1600-h/image%5B11%5D.png
 [2]: http://lh4.ggpht.com/_XlySlDLkdOc/TXf19RxDPBI/AAAAAAAAE6M/ZBzVm30d2LA/s1600-h/image%5B17%5D.png
 [3]: http://lh3.ggpht.com/_XlySlDLkdOc/TXkd12IOBoI/AAAAAAAAE6k/EI6WJqgWEcU/s1600-h/DSCF5074%20-notes%5B4%5D.jpg
 [4]: http://lh5.ggpht.com/_XlySlDLkdOc/TXf1uj2vF_I/AAAAAAAAE6E/GiJygEu9hqM/s1600-h/image%5B12%5D.png