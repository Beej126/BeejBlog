---
title: Transparent Command Shell (Windows)
author: Beej
type: post
date: 2008-07-25T06:36:00+00:00
url: /2008/07/transparent-command-shell-windows.html
blogger_bid:
  - 7726907200224433699
blogger_blog:
  - www.beejblog.com
blogger_id:
  - 1424063778727804550
blogger_author:
  - g108669953529091704409
blogger_permalink:
  - /2008/07/transparent-command-shell-windows.html
blogger_thumbnail:
  - http://www.hanselman.com/blog/content/binary/transparentcommentprompt_thumb.jpg
snapEdIT:
  - 1
snapTW:
  - |
    s:199:"a:1:{i:0;a:7:{s:2:"do";s:1:"1";s:9:"msgFormat";s:27:"%TITLE%
    %URL%
    
    %EXCERPT%";s:8:"attchImg";s:1:"1";s:9:"isAutoImg";s:1:"A";s:8:"imgToUse";s:0:"";s:9:"isAutoURL";s:1:"A";s:8:"urlToUse";s:0:"";}}";
dsq_thread_id:
  - 5542148863
categories:
  - Uncategorized
tags:
  - CmdLine
  - Software
  - SysAdmin

---
Nice, someone&#8217;s gone and created the perfect pill for even the most serious case of Mac OS X Terminal envy&#8230;

<div>
</div>

<div>
  I give you: <a href="http://www.hanselman.com/blog/TransparentCommandPromptInWindows.aspx">Console2</a> !
</div>

<div>
</div>

[<img style="WIDTH: 320px; CURSOR: hand" border="0" alt="" src="http://www.hanselman.com/blog/content/binary/transparentcommentprompt_thumb.jpg" />][1]

<div>
</div>

<div>
</div>

<div>
  It&#8217;s got dang near everything I could ever want to configure&#8230; somebody really loves their command shells mmm hmmm 😛
</div>

<div>
  Only <em>little</em> nit pick I can come up with is that I think the Mac actually allows you to <strong>set the transparency of the just the background</strong>&#8230; so that the text and the outer frame still look crisp and solid.
</div>

 [1]: http://www.hanselman.com/blog/content/binary/transparentcommentprompt_thumb.jpg