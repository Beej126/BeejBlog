---
title: Big Swinging Developer
author: Beej
type: post
date: 2009-11-04T04:59:00+00:00
url: /2009/11/big-swinging-developer.html
blogger_bid:
  - 7726907200224433699
blogger_blog:
  - www.beejblog.com
blogger_id:
  - 7113777519898912612
blogger_author:
  - g108669953529091704409
blogger_comments:
  - 1
blogger_permalink:
  - /2009/11/big-swinging-developer.html
dsq_thread_id:
  - 5508631634
categories:
  - Uncategorized
tags:
  - ProjMgmt

---
Like what Jay Grieves has to say

  * <a href="http://blog.bigswingingdeveloper.com/2009/09/3-words-that-guarantee-success.html" target="_blank">3 Words That Guarantee Success</a> 
  * <a href="http://blog.bigswingingdeveloper.com/2009/03/getting-things-done-vs-making-things-happen.html" target="_blank">Getting Things Done vs. Making Things Happen</a> <ul style="margin-bottom: 0px;">
      <li>
        <b>*** </b><a href="http://blog.bigswingingdeveloper.com/2009/03/the-dead-simple-guide-to-making-things-happen.html" target="_blank"><b>The Dead Simple Guide To Making Things Happen</b></a>
      </li>
    </ul>

  * <a href="http://blog.bigswingingdeveloper.com/2009/08/firstrate-companies-have-firstrate-systems.html" target="_blank">First-Rate Companies Have First-Rate Systems</a>