---
title: Logitech S715i Portable iPod Speakers Review
author: Beej
type: post
date: 2010-09-23T09:13:00+00:00
url: /2010/09/logitech-s715i-portable-ipod-speakers.html
blogger_bid:
  - 7726907200224433699
blogger_blog:
  - www.beejblog.com
blogger_id:
  - 4638777137928376117
blogger_author:
  - g108669953529091704409
blogger_comments:
  - 1
blogger_permalink:
  - /2010/09/logitech-s715i-portable-ipod-speakers.html
blogger_thumbnail:
  - http://lh6.ggpht.com/_XlySlDLkdOc/TIm8piY26HI/AAAAAAAAEwo/tqO2N4XpL6g/image%5B1%5D.png?imgmax=800
snapEdIT:
  - 1
snapTW:
  - |
    s:174:"a:1:{i:0;a:6:{s:2:"do";s:1:"1";s:10:"SNAPformat";s:27:"%TITLE%
    %URL%
    
    %EXCERPT%";s:8:"attchImg";s:1:"1";s:9:"isAutoImg";s:1:"A";s:8:"imgToUse";s:0:"";s:4:"doTW";s:1:"1";}}";
dsq_thread_id:
  - 5508631535
categories:
  - Uncategorized
tags:
  - Biking
  - Hardware
  - Music
  - Outdoors

---
My primary usage scenarios is small group biking… want something that can carry some punchy bass to nearby riders over typical road/wind noise w/o being clunky or adding too much weight (we have to hop on/off a lot of trains/stairs, etc)…

<table border="0" cellspacing="0" cellpadding="2">
  <tr>
    <td valign="top">
    </td>
    
    <td valign="top">
      Highlights
    </td>
    
    <td valign="top">
      Reviews / Links
    </td>
  </tr>
  
  <tr>
    <td valign="top" align="center">
      <a href="http://www.ilounge.com/index.php/reviews/entry/logitech-rechargeable-speaker-s715i/" target="_blank"><img style="border-right-width: 0px; display: inline; border-top-width: 0px; border-bottom-width: 0px; border-left-width: 0px" title="image" border="0" alt="image" src="http://lh6.ggpht.com/_XlySlDLkdOc/TIm8piY26HI/AAAAAAAAEwo/tqO2N4XpL6g/image%5B1%5D.png?imgmax=800" width="344" height="262" /></a> <img style="border-right-width: 0px; display: inline; border-top-width: 0px; border-bottom-width: 0px; border-left-width: 0px" title="image" border="0" alt="image" src="http://lh4.ggpht.com/_XlySlDLkdOc/TID53aaaNLI/AAAAAAAAEws/0h6GKq9xwr8/image5%5B1%5D.png?imgmax=800" width="232" height="177" /> <a href="http://www.virgulestar.com/Photos/2010-09-22%20New%20Logitech%20Bike%20Speakers%20CREE%20Light%20Mount/#8" target="_blank"><img style="border-right-width: 0px; display: inline; border-top-width: 0px; border-bottom-width: 0px; border-left-width: 0px" title="P1030099-800x600" border="0" alt="P1030099-800x600" src="http://lh5.ggpht.com/_XlySlDLkdOc/TJqHVB0KFKI/AAAAAAAAExU/nhIM8o7RfrU/P1030099-800x600%5B6%5D.jpg?imgmax=800" width="240" height="180" /></a>&#160; <a href="http://www.virgulestar.com/Photos/2010-09-22%20New%20Logitech%20Bike%20Speakers%20CREE%20Light%20Mount/#9" target="_blank"><img style="border-right-width: 0px; display: inline; border-top-width: 0px; border-bottom-width: 0px; border-left-width: 0px" title="P1030100-800x600" border="0" alt="P1030100-800x600" src="http://lh3.ggpht.com/_XlySlDLkdOc/TJqHVolOLSI/AAAAAAAAExY/VGILVsy-b20/P1030100-800x600%5B5%5D.jpg?imgmax=800" width="240" height="180" /></a><a href="http://www.virgulestar.com/Photos/2010-09-22%20New%20Logitech%20Bike%20Speakers%20CREE%20Light%20Mount/#1" target="_blank"><img style="border-right-width: 0px; display: inline; border-top-width: 0px; border-bottom-width: 0px; border-left-width: 0px" title="Battery NiMH 180AAHC3TMX 3.6V 1800mAh-800x600" border="0" alt="Battery NiMH 180AAHC3TMX 3.6V 1800mAh-800x600" src="http://lh5.ggpht.com/_XlySlDLkdOc/TJqHWJl2kUI/AAAAAAAAExg/gamC9aZF6Ns/Battery%20NiMH%20180AAHC3TMX%203.6V%201800mAh-800x600%5B5%5D.jpg?imgmax=800" width="240" height="180" /></a>
    </td>
    
    <td valign="top">
      <ul>
        <li>
          <a href="http://www.google.com/products/catalog?hl=en&q=S715i&cid=14381146663424913171&ei=3euATKHRF4L_-QawwsC1Bg&sa=button&ved=0CAkQgggwADgA&os=sellers#scoring=p" target="_blank">Retail: $150, Street: $132</a>
        </li>
        <li>
          Released Aug 2010
        </li>
        <li>
          8 speakers! = 2 x 3” neodymium mid drivers, 2 x 1.5” neodymium tweeters, 4 x 2” passive bass
        </li>
        <li>
          Rechargeable proprietary NiMh battery (highly marketed @ 8 hours)… too bad they’re not rocking a Li-ion slab… but supposedly these batts are user serviceable through a screw panel so we’ll see.
        </li>
        <li>
          3.5 lbs (perfect)
        </li>
        <li>
          Standard 3.5mm AUX input (required for me)
        </li>
        <li>
          Remote (worthless for me)
        </li>
        <li>
          A/C wall brick
        </li>
        <li>
          Travel sack
        </li>
      </ul>
      
      <p>
        My review:
      </p>
      
      <ul>
        <li>
          just gave them a test run tonight 22 Sep 2010
        </li>
        <li>
          they bang pretty nice off the back bike rack
        </li>
        <li>
          compared to the logitech 28mm (eBay = $30, no longer available) they are better enough to be worth $150 to me
        </li>
        <li>
          iPhone compatible
        </li>
        <li>
          feel solid, not as bulky as i expected
        </li>
        <li>
          Battery = NiMH 180AAHC3TMX 3.6V 1800mAh (see photo)
        </li>
      </ul>
    </td>
    
    <td valign="top" width="300">
      <ul>
        <li>
          <a href="http://www.ilounge.com/index.php/reviews/entry/logitech-rechargeable-speaker-s715i/" target="_blank">iLounge deep review</a><br /> <blockquote>
            <p>
              “Unlike its predecessors, S715i has a battery compartment with standard screws that can be opened to swap the rechargeable cell out when it’s non-functional, a positive change that critics of the Pure-Fi series will appreciate.”
            </p>
          </blockquote>
        </li>
        
        <li>
          <a href="http://www.logitech.com/en-us/speakers-audio/ipod-mp3-speakers/devices/7209?WT.ac=ps|7426|hp&reloadcache=wlogi#section=features" target="_blank">Logitech’s product detail page</a>
        </li>
        <li>
          <a href="http://www.google.com/url?sa=t&source=web&cd=1&ved=0CBUQtwIwAA&url=http%3A%2F%2Fwww.youtube.com%2Fwatch%3Fv%3DaaXWkwym1ak&rct=j&q=youtube%20S715i&ei=--uATN-UH8PMswaKg-WnBw&usg=AFQjCNF4Hi055UwDKx2jBaeUobYxo1bUfw&cad=rja" target="_blank">Logitech’s own YouTube demo</a>
        </li>
      </ul>
    </td>
  </tr>
</table>

<table border="0" cellspacing="0" cellpadding="3">
  <tr>
    <td valign="top">
      Batteries!!&#160; I’ve already started maxing out the battery life during our rides… we saw around 6 hours last ride… that’s not 8 hours 🙂 … to be fair, once I turned down the volume, then the light went back green for another hour or so… but who wants low volume!?!? So now I’m looking to hack in some <a href="/2010/09/cree-led-based-bicycle-lights-and.html" target="_blank">Lithium rechargables like what I’ve started to experience with these CREE LED’s</a> I’ve already received one of these buggers to the right ($20 bux, 6 days Air Mail from Hong Kong to Germany! you gotta love the Chinese economy! 🙂 I plan on cannibalizing the battery box and springy cable for feeding the speakers :)&#160; we shall see To answer Peirre’s question in the comments: The direct battery feed is 3.6v (based on an packaged bundle of 3 x 1.2v AA NiCads in series)… but the DC charging input port is rated at 12v so there’s hurdle to get over there… I feel like we could use a fancy more expensive battery pack (<a href="http://www.newegg.com/Product/Product.aspx?Item=N82E16855997152" target="_blank">like the Tekkeon’s</a>) to drive the 12v input in a physically clean but likely power wasteful approach… I’m more inclined to fiddle around tapping the existing battery feed first and see how far I get that way. [Update: 2012 May 05] To finish off this thread, the headlamp at the right was cheap yet very capable as a lighting solution. It was a shame to cannibalize it for the battery pack experiment. And unfortunately, while the pack and cable were physically promising, the arrangement was based on a remote switch at the light head which was not a simple circuit loop that could be shorted to be always on. It was a real bear getting the little wires soldered back to the light head after this disappointment. Fear not. What has worked out quite practically is using a simple 18650 plastic case with wires soldered to pennies on either end to form a simple battery case with power leads. The case also provides an easy place for a spare backup battery… Or one could probably run them in parallel but I haven’t bothered. I removed the stock NiCad battery leads and spliced them to the makeshift 18650 battery pack so that it could be easily connected and removed. The makeshift battery case is too big to fit anywhere inside the original battery cavity but the built in speaker stand lends itself to use as a strap mounting point. Actually, eBay seems to have some <a href="http://www.ebay.com/sch/i.html?_&_nkw=18650+case" target="_blank">nice single 18650 battery cases with leads</a> ready to go.
    </td>
    
    <td valign="top">
      <a href="http://shop.ebay.com/?_nkw=5W+CREE+Q5+LED+HEADLAMP+FLASHLIGHT+2x+18650+Charger" target="_blank"><img style="background-image: none; border-right-width: 0px; padding-left: 0px; padding-right: 0px; display: inline; border-top-width: 0px; border-bottom-width: 0px; border-left-width: 0px; padding-top: 0px" title="Untitled-5" border="0" alt="Untitled-5" src="http://lh6.ggpht.com/_XlySlDLkdOc/TX5vtF1vVbI/AAAAAAAAE7o/wyQNaavwNlQ/Untitled-5%5B6%5D.png?imgmax=800" width="391" height="332" /></a> <br /><a href="http://lh3.ggpht.com/-AkQjeo0G3gY/T6Uj2g-b_SI/AAAAAAAAFFk/Li09KwmKaqE/s1600-h/DSC_6341-medium%25255B5%25255D.jpg"><img style="background-image: none; border-bottom: 0px; border-left: 0px; padding-left: 0px; padding-right: 0px; display: inline; border-top: 0px; border-right: 0px; padding-top: 0px" title="DSC_6341-medium" border="0" alt="DSC_6341-medium" src="http://lh5.ggpht.com/-flEBdnTMFIo/T6Uj3qWpOBI/AAAAAAAAFFo/U3uEFp4kbA0/DSC_6341-medium_thumb%25255B3%25255D.jpg?imgmax=800" width="394" height="272" /></a>
    </td>
  </tr>
  
  <tr>
    <td valign="top">
      Lastly, a buddy got the <a href="http://www.bose.com/controller?url=/shop_online/digital_music_systems/bluetooth_speakers/soundlink_wireless_speaker/index_new.jsp" target="_blank">Bose SoundLink Bluetooth speakers</a> and I definitely consider them another notch or two up this ladder. <br />Highlights: </p> 
      
      <ul>
        <li>
          $300 – this is the only downside really
        </li>
        <li>
          The internal battery pack is made of no less than 3 good ol’ 18650’s! Yay! finally somebody gets it!
        </li>
        <ul>
          <li>
            They’re rated pretty low (less than 2000mAh if memory serves)… so beyond the already good base 10 hour rating, presumably there’s some good room for improvement with solid upgrade cells, like the latest <a href="http://www.redilast.com/index.php?option=com_content&view=article&id=56&Itemid=88" target="_blank">Redilast 3100mAh</a>’s.
          </li>
          <li>
            From what we could tell after getting the battery cage open (there are screws under a label), the cells appear to be bare, i.e. no protective cap chip. There’s a pretty dense logic board right after the cells so presumably it’s all well buffered from spikes.
          </li>
          <li>
            I emailed the owner and he indicated $14 a piece for the naked 3100’s in qty 5 or greater.
          </li>
        </ul>
        
        <li>
          Bluetooth is pretty handy with today’s devices… there’s also a standard 3.5mm AUX port.
        </li>
        <li>
          A bit more sound <em>punch</em> for sure… very clear…
        </li>
        <li>
          nice tight, well built, rectangular package that lends itself to bungee’ing to a rear bike rack, etc.
        </li>
        <li>
          also, the cover can be easily removed which leaves some raised Allen screws convenient for mounting.
        </li>
      </ul>
    </td>
    
    <td valign="top">
      <a href="http://www.amazon.com/Bose-SoundLink-Wireless-Mobile-Speaker/dp/B005KFONIU/ref=sr_1_1?ie=UTF8&qid=1336223807&sr=8-1" target="_blank"><img alt="" src="http://www.bose.com/assets/images/shop_online/digital_music_systems/wireless_systems/soundlink_wireless_speaker_new/sl_lifestyle_hand.jpg" width="364" height="252" /></a>
    </td>
  </tr>
</table>