---
title: Awesome, CAD for LEGOs!
author: Beej
type: post
date: 2009-01-15T04:21:00+00:00
url: /2009/01/awesome-cad-for-legos.html
blogger_bid:
  - 7726907200224433699
blogger_blog:
  - www.beejblog.com
blogger_id:
  - 7558525206413389348
blogger_author:
  - g108669953529091704409
blogger_permalink:
  - /2009/01/awesome-cad-for-legos.html
blogger_thumbnail:
  - http://cache.lego.com/upload/contentTemplating/LDDHomepage/images/2057/picE9286D5C-661B-4152-8292-8560AECF75EF.jpg
snapEdIT:
  - 1
snapTW:
  - |
    s:199:"a:1:{i:0;a:7:{s:2:"do";s:1:"1";s:9:"msgFormat";s:27:"%TITLE%
    %URL%
    
    %EXCERPT%";s:8:"attchImg";s:1:"1";s:9:"isAutoImg";s:1:"A";s:8:"imgToUse";s:0:"";s:9:"isAutoURL";s:1:"A";s:8:"urlToUse";s:0:"";}}";
dsq_thread_id:
  - 5542148975
categories:
  - Uncategorized
tags:
  - Fun
  - Software

---
ok i know it&#8217;s been around for ages apparently&#8230; but man that&#8217;s awesome anybody do a hard drive cage in the "technic" rivit oriented pieces yet? 🙂 highlights:

  * it actually "knows" when you put two technic "i-beams" together on a rivet pivot point&#8230; it&#8217;ll rotate them in 3D so you can line things up with true geometry! 
  * it adds up the whole parts list and gives you a total price to physically manifest your creation <nifty> 
  * people can & are publishing their custom designs 
  * it copies multi-part "bundles" and flips/rotates them easily to construct symmetric objects quickly 

[![Get Started][1]][2]

 [1]: http://cache.lego.com/upload/contentTemplating/LDDHomepage/images/2057/picE9286D5C-661B-4152-8292-8560AECF75EF.jpg
 [2]: http://ldd.lego.com/