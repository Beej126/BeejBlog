---
title: Going Portrait!
author: Beej
type: post
date: 2011-06-25T17:38:00+00:00
url: /2011/06/going-portrai.html
blogger_bid:
  - 7726907200224433699
blogger_blog:
  - www.beejblog.com
blogger_id:
  - 1711126932577215288
blogger_author:
  - g108669953529091704409
blogger_permalink:
  - /2011/06/going-portrait.html
blogger_thumbnail:
  - http://lh5.ggpht.com/-dtzBPoQp2m0/TgW6vSGaG3I/AAAAAAAAE8c/p_TCvGk9ybw/clip_image001_thumb%25255B3%25255D.jpg?imgmax=800
dsq_thread_id:
  - 6195455681
categories:
  - Uncategorized
tags:
  - Hardware

---
Do you realize how freakin’ cool it is to be able to hit ALT-F1 on a table in SSMS and be able to immediately view all of the output without futzing around in all the little result-set scroll bars!?! There’s 6 tables that come back from sp_help and now they have the room they deserve… the visual query plan tool is more horizontal so I have a feeling that’s going to take a little hit… we’ll see. Great for dual pane WPF dev in VS2010 too… with a typical visual pane up top, there’s now tons more room for raw XAML in the bottom … and XAML gets verbose in a hurry so this was becoming a critical annoyance for me. And not only dev oriented activities, Outlook feels better too… and it’s amazing how many web pages seem like they were made for portait… so nice to see a whole page at once w/o a scroll bar. Bottom line: THE most dramatic yet drop dead easy computer improvement I’ve done in a long time. [<img style="background-image: none; border-right-width: 0px; padding-left: 0px; padding-right: 0px; display: inline; border-top-width: 0px; border-bottom-width: 0px; border-left-width: 0px; padding-top: 0px" title="clip_image001" border="0" alt="clip_image001" src="http://lh5.ggpht.com/-dtzBPoQp2m0/TgW6vSGaG3I/AAAAAAAAE8c/p_TCvGk9ybw/clip_image001_thumb%25255B3%25255D.jpg?imgmax=800" width="685" height="528" />][1]

 [1]: http://lh6.ggpht.com/-386Laxuq5fc/TgW6uvMmjoI/AAAAAAAAE8Y/kW-0tlMUutI/s1600-h/clip_image001%25255B6%25255D.jpg