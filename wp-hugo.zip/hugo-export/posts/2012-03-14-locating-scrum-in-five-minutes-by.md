---
title: Locating “Scrum In Five Minutes” By www.Softhouse.se
author: Beej
type: post
date: 2012-03-15T03:15:00+00:00
url: /2012/03/locating-scrum-in-five-minutes-by.html
blogger_bid:
  - 7726907200224433699
blogger_blog:
  - www.beejblog.com
blogger_id:
  - 8586112628045311370
blogger_author:
  - g108669953529091704409
blogger_permalink:
  - /2012/03/locating-scrum-in-five-minutes-by.html
dsq_thread_id:
  - 5849360471
categories:
  - Uncategorized
tags:
  - ProjMgmt

---
It’s not on their main downloads page anymore. Here’s their registration page with immediate PDF download after: <s>[http://softhouseeducation.com/material/scrum-five-minutes][1]</s>
  
[Updated download][2], now via free cart checkout

 [1]: http://softhouseeducation.com/material/scrum-five-minutes "http://softhouseeducation.com/material/scrum-five-minutes"
 [2]: http://softhouseeducation.se/produkt/scrum-pa-fem-minuter-2?attribute_pa_format=pdf&attribute_pa_sprak=engelska