---
title: 'Blu-ray Burner & Media Shopping'
author: Beej
type: post
date: 2010-11-12T17:10:00+00:00
url: /2010/11/blu-ray-burner-media-shopping.html
blogger_bid:
  - 7726907200224433699
blogger_blog:
  - www.beejblog.com
blogger_id:
  - 8772041583613207553
blogger_author:
  - g108669953529091704409
blogger_permalink:
  - /2010/11/blu-ray-burner-media-shopping.html
tags:
  - Hardware

---
Burner: **Pioneer BDR-206** 

  * <a href="http://www.provantage.com/pioneer-bdr-206bk~7PION12L.htm" target="_blank">Provantage has brown box OEM for $130.37</a> (+ $11.70 APO shipping) 
  * Dual Layer capable 
  * 3D capable (whatever that means) 
  * Write: 12x BD-R (DL), 2x BD-RE (DL), 5x DVD-RAM, 16x DVD±R, 8x DVD±R DL, 6x DVD-RW, 8x DVD+RW, 40x CD-R, 24x CD-RW 
  * Read: 8x BD-R/RE/ROM (DL), 6x BD-RE DL, 5x DVD-RAM, 16x DVD-ROM, 40x CD-ROM 
  * 4MB cache 
  * <a href="http://forums.dpreview.com/forums/read.asp?forum=1004&message=36712894" target="_blank">some write performance competitive comparison specs</a> 

Media: 

  * <a href="http://www.vinpowerdigital.com/Products/Media/OQBP/OQBP.asp" target="_blank">Vinpower’s “Optical Quantum Best Print”</a> product line is competitively priced and covers the specialty gamut well (hub printable, etc) 
      * In particular, the Water-Resistant Media using “Liquid-Defense” version sounds pretty cool: _The OQBP water-resistant media is a new innovation using nanoparticle technology. It secures the printed matter to the disc preventing moisture from separating the ink which causes smearing and bleeding._ 
      * Rated at 4x for BD-R \*BUT\* <a href="http://www.runtechmedia.com/product.asp?sku=OQP-BD-R-04-IPW-10" target="_blank">RunTechMedia.com says</a> – “_This media can record up to 8x speed in certain 8x or higher speed Blu-ray burners, please refer compatibility list for more info._” and goes on to list the previous gen Pioneer BDR-205 as capable of 10x with these discs (sweet 🙂 
      * <a href="http://www.google.com/search?q=Optical+Quantum+25GB+4x+BD-R+Liquid-Defense+25+pack&hl=en&tbs=shop%3A1&aq=f#sclient=psy&hl=en&biw=1920&bih=1015&tbs=shop:1%2Cp_ord%3Ap&q=Optical+Quantum+liquid-defense+25GB+25+pack&aq=f&aqi=&aql=&oq=&gs_rfai=&pbx=1&fp=d6db1f2b384cc15c" target="_blank">Google Shopping Search</a>&#160; 
      * <a href="http://www.runtechmedia.com/MediaSearchResult.asp?a=11&CategoryID=&Manufacturer=Optical%20Quantum&Format=BD-R" target="_blank">RunTechMedia.com has competitive prices</a> 
          * <a href="http://www.runtechmedia.com/product.asp?sku=OQP-BD-R-04-IPW-10" target="_blank">OQBDR04LDWIP (White, Hub Printable, with <u>Liquid Defense</u>) 10pack = $30</a> ($3 a disc is a little rich for my purposes, i.e. photo backups initially) 
          * <a href="http://www.runtechmedia.com/product.asp?sku=OQBDR04GWIP-H" target="_blank">OQBDR04GWIP-H (*GLOSSY* White, Hub, NOT water proof) 25 pack = $46.25</a> ($1.85 is top end of _ok_ in my book, fair tradeoff if I do want to print something for friends) 
          * \*NOTE\*: VinpowerDigital.com doesn’t promote all the various formats they actually manufacture…I originally missed that there was even a glossy version available… if you’re not up for the top end pricey Liquid Defense, I absolutely recommend ***<u>GLOSSY</u>*** white finish at least… the plain white (i.e. “matt”) finish I’ve tried once on another generic brand was much less impressive… it only ups the cost of the 25 pack by $6.24 over the non-glossy format (OQBDR04WIP-H) and I think it’s totally worth it. 
          * RunTechMedia had solid eMail sales support and actually price matched Provantage on the Pioneer burner, for a markdown of $40 (schwing!) 
          * They charge $9.55 for APO \*PRIORITY\* shipping on single spindle case qtys… that’s fair 
          * fyi, even though their confirmation email listed depressing "Media Mail", my package did arrive promptly via Priority as quoted.