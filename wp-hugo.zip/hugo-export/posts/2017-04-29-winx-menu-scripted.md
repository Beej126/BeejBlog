---
title: Win+X Menu scripted
author: Beej
type: post
date: 2017-04-29T07:05:09+00:00
url: /2017/04/winx-menu-scripted.html
dsq_thread_id:
  - 5770060104
categories:
  - Uncategorized
tags:
  - CmdLine

---
