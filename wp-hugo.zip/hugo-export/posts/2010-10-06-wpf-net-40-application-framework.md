---
title: WPF .Net 4 LOB Application Framework
author: Beej
type: post
date: 2010-10-06T22:19:00+00:00
url: /2010/10/wpf-net-40-application-framework.html
blogger_bid:
  - 7726907200224433699
blogger_blog:
  - www.beejblog.com
blogger_id:
  - 4890257655956514364
blogger_author:
  - g108669953529091704409
blogger_permalink:
  - /2010/10/wpf-net-40-application-framework.html
dsq_thread_id:
  - 5545468549
snapEdIT:
  - 1
snapTW:
  - |
    s:199:"a:1:{i:0;a:7:{s:2:"do";s:1:"1";s:9:"msgFormat";s:27:"%TITLE%
    %URL%
    
    %EXCERPT%";s:8:"attchImg";s:1:"1";s:9:"isAutoImg";s:1:"A";s:8:"imgToUse";s:0:"";s:9:"isAutoURL";s:1:"A";s:8:"urlToUse";s:0:"";}}";
enclosure:
  - |
    |
        https://www.BeejBlog.com/wp-content/uploads/2010/10/WPF_Elastic_UI_Demo.mp4
        933901
        video/mp4
        
categories:
  - Uncategorized
tags:
  - Database
  - WPF

---
<div style="width: 525px;" class="wp-video">
  <!--[if lt IE 9]><![endif]--><video class="wp-video-shortcode" id="video-87-1" width="525" height="425" preload="metadata" controls="controls"><source type="video/mp4" src="https://www.BeejBlog.com/wp-content/uploads/2010/10/WPF_Elastic_UI_Demo.mp4?_=1" />
  
  <a href="https://www.BeejBlog.com/wp-content/uploads/2010/10/WPF_Elastic_UI_Demo.mp4">https://www.BeejBlog.com/wp-content/uploads/2010/10/WPF_Elastic_UI_Demo.mp4</a></video>
</div>

([Wikipedia: LOB][1])

[GitHub Repo][2]&#8230; key items flagged with &#8220;nugget:&#8221; comment

 [1]: http://en.wikipedia.org/wiki/Line_of_business
 [2]: https://github.com/Beej126/itraacv2-1