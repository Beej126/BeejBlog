---
title: 'Style all <select>’s with a given CSS class into a fancy radio button look'
author: Beej
type: post
date: 2014-08-28T10:40:00+00:00
url: /2014/08/radioselec.html
blogger_bid:
  - 7726907200224433699
blogger_blog:
  - www.beejblog.com
blogger_id:
  - 8616566783643612773
blogger_author:
  - g108832383968142578199
blogger_permalink:
  - /2014/08/RadioSelect.html
blogger_thumbnail:
  - http://3.bp.blogspot.com/-0vwpFifFiYY/U_6k61k9F_I/AAAAAAAAIrs/ku-dsGXukB4/s1600/8-27-2014%2B8-40-58%2BPM.png
snapEdIT:
  - 1
snapTW:
  - |
    s:174:"a:1:{i:0;a:6:{s:2:"do";s:1:"1";s:10:"SNAPformat";s:27:"%TITLE%
    %URL%
    
    %EXCERPT%";s:8:"attchImg";s:1:"1";s:9:"isAutoImg";s:1:"A";s:8:"imgToUse";s:0:"";s:4:"doTW";s:1:"1";}}";
dsq_thread_id:
  - 6308755601
categories:
  - Uncategorized
tags:
  - WebDev

---
<a style="font-size: x-large;" href="http://stackoverflow.com/a/25455374/813599">http://stackoverflow.com/a/25455374/813599</a>

<a href="http://www.BeejBlog.com/wp-content/uploads/2014/08/8-27-20148-40-58PM.png" imageanchor="1" ><img border="0" src="http://www.BeejBlog.com/wp-content/uploads/2014/08/8-27-20148-40-58PM.png" /></a>