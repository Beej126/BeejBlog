---
title: Very interesting (old) BBC series by James Burke – tracks the thread of inventions underlying our specialized society
author: Beej
type: post
date: 2009-05-27T21:12:00+00:00
url: /2009/05/very-interesting-old-bbc-series-by.html
blogger_bid:
  - 7726907200224433699
blogger_blog:
  - www.beejblog.com
blogger_id:
  - 7876196107130767033
blogger_author:
  - g108669953529091704409
blogger_permalink:
  - /2009/05/very-interesting-old-bbc-series-by.html
tags:
  - Fun
  - Life
  - Video

---
[http://www.youtube.com/results?search\_type=&search\_query=james+burke&aq=f][1]
  
I’ve watched episodes 1-4 so far… 4 is a pretty good one
  
Simply starting at the beginning seems good too
  
Make sure you take advantage of the preconfigured playlists &#8212; look for “(play all)” &#8212; so they queue up and you can watch them straight through w/o having to continually find the next one &#8212; which really takes away from the enjoyment after a while
  
Search for “james burke episode xxx” to dial in on each bundle if you’re not seeing it from the URL I gave above… there appear to be at least up to 20 episodes
  
(btw: My buddy Joel turned me on to it… he’s full of nifty idears… here’s a gratuitous plug for his vlog site: [http://joelart.blip.tv/][2])

 [1]: http://www.youtube.com/results?search_type=&search_query=james+burke&aq=f
 [2]: http://joelart.blip.tv/ "http://joelart.blip.tv/"