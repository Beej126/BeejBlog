---
title: GPS / Mapping / Garmin – Tips
author: Beej
type: post
date: 2009-08-17T19:48:00+00:00
url: /2009/08/gps-mapping-garmin-tips.html
blogger_bid:
  - 7726907200224433699
blogger_blog:
  - www.beejblog.com
blogger_id:
  - 250900133577193315
blogger_author:
  - g108669953529091704409
blogger_permalink:
  - /2009/08/gps-mapping-garmin-tips.html
dsq_thread_id:
  - 5660206926
tags:
  - Mapping

---
  * <a href="http://www.elsewhere.org/journal/gmaptogpx" target="_blank">GMapToGPX</a> – Export Google Maps route to GPX which then imports to all Garmin stuff ,etc.
  * <a href="http://connect.garmin.com" target="_blank">Garmin Connect.com</a> – Seems like a fun way to start posting our routes and sharing.
  * <a href="http://www.mapmyride.com/search?txtLocation=heidelberg+germany&txtKeyword=&lstSortBy=cs.view_count+desc&lstDistanceMin=&lstDistanceMax=&lstRatingMin=&lstRatingMax=&lstRouteTypeID=&btnSearch=SEARCH+%3E" target="_blank">MapMyRide.com</a> &#8211; route sharing forum that does have Germany content