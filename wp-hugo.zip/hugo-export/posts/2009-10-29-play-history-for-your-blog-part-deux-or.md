---
title: WinAmp Play History Blog “Badge”
author: Beej
type: post
date: 2009-10-30T05:53:00+00:00
url: /2009/10/play-history-for-your-blog-part-deux-or.html
blogger_bid:
  - 7726907200224433699
blogger_blog:
  - www.beejblog.com
blogger_id:
  - 4934038909774388334
blogger_author:
  - g108669953529091704409
blogger_comments:
  - 1
blogger_permalink:
  - /2009/10/play-history-for-your-blog-part-deux-or.html
blogger_thumbnail:
  - http://lh3.ggpht.com/_XlySlDLkdOc/Suoc_HXEkaI/AAAAAAAAEmY/tozgHSkaPM0/image_thumb%5B1%5D.png?imgmax=800
dsq_thread_id:
  - 5508631400
snapEdIT:
  - 1
snapTW:
  - |
    s:199:"a:1:{i:0;a:7:{s:2:"do";s:1:"1";s:9:"msgFormat";s:27:"%TITLE%
    %URL%
    
    %EXCERPT%";s:8:"attchImg";s:1:"1";s:9:"isAutoImg";s:1:"A";s:8:"imgToUse";s:0:"";s:9:"isAutoURL";s:1:"A";s:8:"urlToUse";s:0:"";}}";
categories:
  - Uncategorized
tags:
  - Music

---
## update: alas, yahoo pipes is no more : (

&nbsp;

  * So hopefully you’re already a WinAmp fan if you’re reading this but if not, load up the latest [WinAmp][1] (v5.56 at the moment)
  * [Orgler][2] is the name for WinAmp’s recent Play History plug-in
  * Sign up for a music.AOL.com account via the Orgler options menu shown below (this provides the bucket for your personal play history data… takes 2 seconds, no fee)
  * Play some music 🙂
  * (a) Your feed will start showing up at a URL like this: [http://music.aol.com/profile/beej126@hotmail.com][3]
  * Now here’s the fun part… fire up [Yahoo Pipes][4]
  * Search for Orgler and you should find my published pipe that already does the right filtering
  * Clone it and replace the “Fetch Page” URL with your own like (a) above
  * Then you can publish it to your blog with various badges… sure wish I could show you a screenshot of that but the Yahoo gods appear to have the [pipe usage quota dialed way down low… I run into 999 errors all over the place.][5]
  * I didn’t have any luck with the specific Blogger badge… never changed from a continual “working on it…” style generic Pipes image… So I just went with a plain vanilla RSS feed widget. 
    [![image][6]][7] [![image][8]][9] [![image][10]][11]

 [1]: http://www.winamp.com/media-player/
 [2]: http://blog.winamp.com/2009/07/02/winamp-charts-and-orgler-tutorial/2
 [3]: http://music.aol.com/profile/beej126@hotmail.com "http://music.aol.com/profile/beej126@hotmail.com"
 [4]: http://pipes.yahoo.com/
 [5]: http://pipes.yahoo.com/pipes/docs?doc=troubleshooting#q11
 [6]: http://lh3.ggpht.com/_XlySlDLkdOc/Suoc_HXEkaI/AAAAAAAAEmY/tozgHSkaPM0/image_thumb%5B1%5D.png?imgmax=800 "image"
 [7]: http://lh6.ggpht.com/_XlySlDLkdOc/Suoc-oOp5AI/AAAAAAAAEmU/oiXk1Yhx_ww/s1600-h/image%5B3%5D.png
 [8]: http://lh5.ggpht.com/_XlySlDLkdOc/Suoc_wg7nVI/AAAAAAAAEmg/JtpxVggWjQs/image_thumb%5B4%5D.png?imgmax=800 "image"
 [9]: http://lh3.ggpht.com/_XlySlDLkdOc/Suoc_lsujRI/AAAAAAAAEmc/FELJ2cSgM2g/s1600-h/image%5B8%5D.png
 [10]: http://lh6.ggpht.com/_XlySlDLkdOc/SuodBW4C9qI/AAAAAAAAEmo/CLDy-Aq0Zg8/image_thumb%5B7%5D.png?imgmax=800 "image"
 [11]: http://lh3.ggpht.com/_XlySlDLkdOc/SuodAn4iB0I/AAAAAAAAEmk/l589zXYKSV4/s1600-h/image%5B13%5D.png