---
title: Crazy Proxy Remote Virtual World, or – my first courtship with Google Voice
author: Beej
type: post
date: 2009-07-17T15:45:00+00:00
url: /2009/07/crazy-proxy-remote-virtual-world.html
blogger_bid:
  - 7726907200224433699
blogger_blog:
  - www.beejblog.com
blogger_id:
  - 4937496169396772723
blogger_author:
  - g108669953529091704409
blogger_comments:
  - 2
blogger_permalink:
  - /2009/07/crazy-proxy-remote-virtual-world.html
dsq_thread_id:
  - 5517579749
tags:
  - Synthesis

---
Live in Germany, just got invited to Google Voice (YES!)… anxious to get this rolling so RDP’d into my home machine from work …. course Google don’t support outside US yet but I only want a US number to give to my friends back home anyway … immediately went Proxy spelunking… landed on PHProxy first since it has a convenient FireFox plugin… got me through the front door on the Google Voice US check but all the Ajax stuff was failing… FoxyProxy next… hmm lots of instructions… looks flexible… why don’t any of these things comes with a default proxy list yet???&nbsp; plugged in a proxy from nntime.com… that resolved to an Amazon.com server of all places… Google caught it and blocked … chose another one on port 443… that seems to be working much better … cool I get a list of numbers to choose from now!&nbsp; Bonus! one of them in area code (Chicagoland &#8211; 708) even has my preferred nickname embedded nicely at the end of the number 🙂 … ok now they want a forwarding number, guess I’ll plug in my Skype “Online Number” that i’ve been using while waiting for Google Voice to show me some love… cool they accepted it… ok now they call it for verification… gotta plug in a number when they call… looks like i should be able to with Skype little keypad thingy… damn, it’s not taking and i don’t have any audio at work… WAIT, i have a pair of crappy speakers in the closet!&nbsp; ok i can hear them prompting me now… but it still won’t take the code entered on the keypad <arg>!!! multiple tries, all of them say “&#8217;i’m sorry i can’t recognize your entry”… guess i gotta wait ‘til i get home… sure hope the issue is with the remoting in and not with the Skype translation… guess wost case i’ll get a buddy to answer the Google call 🙂&nbsp; AWESOME!&nbsp; Skype-In worked like a champ directly from my desktop at home… i’m in baby!!