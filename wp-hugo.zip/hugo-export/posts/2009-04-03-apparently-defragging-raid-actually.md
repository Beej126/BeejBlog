---
title: Apparently Defragging RAID Actually Makes Sense
author: Beej
type: post
date: 2009-04-03T16:54:00+00:00
url: /2009/04/apparently-defragging-raid-actually.html
blogger_bid:
  - 7726907200224433699
blogger_blog:
  - www.beejblog.com
blogger_id:
  - 640189590645547347
blogger_author:
  - g108669953529091704409
blogger_permalink:
  - /2009/04/apparently-defragging-raid-actually.html
tags:
  - Hardware
  - SysAdmin

---
[Disk Defragmentation in RAID and SAN Environments][1]

 [1]: http://www.perfectdisk.com/user_data/white_papers/raid_san_environment.pdf "FAT Disk Defragmentation in RAID and SAN Environments"