---
title: Expression Blend 4 + SketchFlow is pretty dang cool
author: Beej
type: post
date: 2010-10-08T05:39:00+00:00
url: /2010/10/expression-blend-4-sketchflow-is-pretty.html
blogger_bid:
  - 7726907200224433699
blogger_blog:
  - www.beejblog.com
blogger_id:
  - 6410419800635778012
blogger_author:
  - g108669953529091704409
blogger_permalink:
  - /2010/10/expression-blend-4-sketchflow-is-pretty.html
blogger_thumbnail:
  - http://lh3.ggpht.com/_XlySlDLkdOc/TK5MMPFUtiI/AAAAAAAAEzI/B4evFQ2fHxg/image_thumb%5B3%5D.png?imgmax=800
snapEdIT:
  - 1
snapTW:
  - |
    s:199:"a:1:{i:0;a:7:{s:2:"do";s:1:"1";s:9:"msgFormat";s:27:"%TITLE%
    %URL%
    
    %EXCERPT%";s:8:"attchImg";s:1:"1";s:9:"isAutoImg";s:1:"A";s:8:"imgToUse";s:0:"";s:9:"isAutoURL";s:1:"A";s:8:"urlToUse";s:0:"";}}";
dsq_thread_id:
  - 5753664575
categories:
  - Uncategorized
tags:
  - ProjMgmt

---
[<img style="border-bottom: 0px; border-left: 0px; display: inline; border-top: 0px; border-right: 0px" title="image" border="0" alt="image" src="http://lh3.ggpht.com/_XlySlDLkdOc/TK5MMPFUtiI/AAAAAAAAEzI/B4evFQ2fHxg/image_thumb%5B3%5D.png?imgmax=800" width="749" height="532" />][1] I’m just getting my feet wet with a silly little project… i wanted to create a high res icon for <a href="http://www.angelfire.com/falcon/speedload/Enabler.htm" target="_blank">Windows Enabler</a> in my <a href="http://www.stardock.com/products/objectdock/" target="_blank">ObjectDock</a>… turned out decent: [<img style="border-bottom: 0px; border-left: 0px; display: inline; border-top: 0px; border-right: 0px" title="image" border="0" alt="image" src="http://lh6.ggpht.com/_XlySlDLkdOc/TK5MNP1fmGI/AAAAAAAAEzQ/JN_ZrN3Qrdk/image_thumb%5B8%5D.png?imgmax=800" width="284" height="285" />][2] [<img style="border-bottom: 0px; border-left: 0px; display: inline; border-top: 0px; border-right: 0px" title="image" border="0" alt="image" src="http://lh5.ggpht.com/_XlySlDLkdOc/TK5M8wVzUNI/AAAAAAAAEzY/c11216yGOzg/image_thumb%5B11%5D.png?imgmax=800" width="493" height="206" />][3]

 [1]: http://lh5.ggpht.com/_XlySlDLkdOc/TK5MLDZaf9I/AAAAAAAAEzE/wrQF653LnQM/s1600-h/image%5B5%5D.png
 [2]: http://lh6.ggpht.com/_XlySlDLkdOc/TK5MMn4RUsI/AAAAAAAAEzM/ZFWTItQExrU/s1600-h/image%5B14%5D.png
 [3]: http://lh4.ggpht.com/_XlySlDLkdOc/TK5M8G0BUjI/AAAAAAAAEzU/hfsw3Nve9Rs/s1600-h/image%5B19%5D.png