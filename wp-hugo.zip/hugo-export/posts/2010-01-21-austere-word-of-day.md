---
title: Word of the Day – Austere
author: Beej
type: post
date: 2010-01-22T04:18:00+00:00
url: /2010/01/austere-word-of-day.html
blogger_bid:
  - 7726907200224433699
blogger_blog:
  - www.beejblog.com
blogger_id:
  - 8695709306608371786
blogger_author:
  - g108669953529091704409
blogger_permalink:
  - /2010/01/austere-word-of-day.html
tags:
  - Fun

---
Adjective: austere    
1. Severely simple    
2. Of a stern or strict bearing or demeanor; forbidding in aspect   
&#160;&#160;&#160;&#160; "an austere expression"    
3. Practicing great self-denial   
&#160;&#160;&#160;&#160; "a desert nomad&#8217;s austere life"