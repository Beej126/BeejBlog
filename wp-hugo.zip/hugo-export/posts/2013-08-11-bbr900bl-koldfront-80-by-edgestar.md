---
title: Man Cave Bling – Beer Fridge – Koldfront 80 (BBR900BL) by EdgeStar
author: Beej
type: post
date: 2013-08-11T05:19:00+00:00
url: /2013/08/bbr900bl-koldfront-80-by-edgestar.html
blogger_bid:
  - 7726907200224433699
blogger_blog:
  - www.beejblog.com
blogger_id:
  - 8666866801867179541
blogger_author:
  - g108669953529091704409
blogger_permalink:
  - /2013/08/bbr900bl-koldfront-80-by-edgestar.html
blogger_thumbnail:
  - http://demandware.edgesuite.net/aabh_prd/on/demandware.static/Sites-ES-Site/Sites-EdgeStar/default/v1375862139810/products/viewlarger/BBR900BL_vl1.jpg
snapEdIT:
  - 1
snapTW:
  - |
    s:199:"a:1:{i:0;a:7:{s:2:"do";s:1:"1";s:9:"msgFormat";s:27:"%TITLE%
    %URL%
    
    %EXCERPT%";s:8:"attchImg";s:1:"1";s:9:"isAutoImg";s:1:"A";s:8:"imgToUse";s:0:"";s:9:"isAutoURL";s:1:"A";s:8:"urlToUse";s:0:"";}}";
dsq_thread_id:
  - 5542135581
categories:
  - Uncategorized
tags:
  - Fun
  - Hardware
  - Life

---
<a href="http://www.edgestar.com/Koldfront-80-Can-Built-In-Beverage-Cooler-Black/BBR900BL,default,pd.html?cgid=Wine_and_Beverage-Beverage_Refrigerators" target="_blank"><img title="View larger image of Koldfront 80 Can Built-In Beverage Cooler - Black" style="border-left-width: 0px; border-right-width: 0px; background-image: none; border-bottom-width: 0px; float: right; padding-top: 0px; padding-left: 0px; margin: 0px 0px 0px 10px; display: inline; padding-right: 0px; border-top-width: 0px" border="0" alt="View larger image of Koldfront 80 Can Built-In Beverage Cooler - Black" align="right" src="http://demandware.edgesuite.net/aabh_prd/on/demandware.static/Sites-ES-Site/Sites-EdgeStar/default/v1375862139810/products/viewlarger/BBR900BL_vl1.jpg" width="308" height="313" /></a>

  * First one was a dud out of the box. Just didn’t cool at all. EdgeStar support said it was missing coolant. Took them about 2 full weeks to turn around the replacement. They paid all replacement shipping via printed return label. It was a new serial number, not a repair of my old one, and it looked new. 
      * I am very satisfied now with this second unit and would definitely recommend it. 
          * The look is very nice. The glass is great. The blue light is great. 
              * The size is great, very deep. Fit my under-the-bar-cabinet-slot really well. A little shorter than the broken down old “Scotsman” that was in there but nothing a couple 2x4’s didn’t fix. 
                  * Sure am glad to have found something in a more reasonable price range… I’m sure the Scotsman stuff must last forever but at upwards of $2k, not on my kids’ college budget 🙂
                  * Cooling has been spot on for the 2 months I’ve had it so far <knock wood>. 
                      * The cheapest I was able to find it was from <a href="http://www.idealwinecoolers.com/product/BBR900BL_Koldfront-80-Can-Black-Built-In-Locking-Beverage-Cooler" target="_blank">“Ideal Wine Coolers” for $400</a>. Half retail and $100 less than Amazon. 
                          * Other considerations for this same general form factor are the: 
                              * <a href="http://www.idealwinecoolers.com/product/CBR901SG_EdgeStar-94-Can-Silver-Trim-Built-In-Locking-Beverage-Cooler" target="_blank">“EdgeStar 80” (CBR901SG)</a> for <a href="http://www.idealwinecoolers.com/product/CBR901SG_EdgeStar-94-Can-Silver-Trim-Built-In-Locking-Beverage-Cooler" target="_blank">$500</a> if you’re interested in the stainless steel look, and the 
                                  * <a href="http://www.idealwinecoolers.com/product/OBR900SS_Edgestar-84-Can-Glass-Door-Outdoor-Stainless-Beverage-Cooler" target="_blank">“EdgeStar 84” (OBR900SS)</a> for <a href="http://www.idealwinecoolers.com/product/OBR900SS_Edgestar-84-Can-Glass-Door-Outdoor-Stainless-Beverage-Cooler" target="_blank">$750</a> if you want outdoor certified cooling capability[<img title="DSC_0991-50%" style="border-left-width: 0px; border-right-width: 0px; background-image: none; border-bottom-width: 0px; float: right; padding-top: 0px; padding-left: 0px; margin: 10px 0px 0px 10px; display: inline; padding-right: 0px; border-top-width: 0px" border="0" alt="DSC_0991-50%" align="right" src="http://lh5.ggpht.com/-xX8mJpX2V0s/UgclR_CqpXI/AAAAAAAAFUU/p-IbYLghDv4/DSC_0991-50%252525_thumb%25255B5%25255D.jpg?imgmax=800" width="272" height="450" />][1]… they indicate that a unit should be specifically designed to run outdoors or it will burn itself out quickly running non stop… that one would look great next to a hot tub 🙂</ul> 
                            
                            [<img title="DSC_0967-50%" style="border-left-width: 0px; border-right-width: 0px; background-image: none; border-bottom-width: 0px; padding-top: 0px; padding-left: 0px; margin: 9px 0px 0px; display: inline; padding-right: 0px; border-top-width: 0px" border="0" alt="DSC_0967-50%" src="http://lh5.ggpht.com/-VPE2p8qMo_k/UgclSxbujqI/AAAAAAAAFUk/cObYpeqtMYA/DSC_0967-50%252525_thumb%25255B3%25255D.jpg?imgmax=800" width="569" height="406" />][2]

 [1]: http://lh3.ggpht.com/-JhGn938ZGCo/UgclRZhW9QI/AAAAAAAAFUM/fmE2K3tnk54/s1600-h/DSC_0991-50%252525%25255B7%25255D.jpg
 [2]: http://lh6.ggpht.com/-gxAUjl1kPXE/UgclSVxZY7I/AAAAAAAAFUc/1iGd2E35W18/s1600-h/DSC_0967-50%252525%25255B5%25255D.jpg