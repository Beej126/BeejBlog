---
title: Cisco VPN and "Split Tunneling"
author: Beej
type: post
date: 2009-01-23T01:25:00+00:00
url: /2009/01/cisco-vpn-and-tunneling.html
blogger_bid:
  - 7726907200224433699
blogger_blog:
  - www.beejblog.com
blogger_id:
  - 4615335820844046508
blogger_author:
  - g108669953529091704409
blogger_permalink:
  - /2009/01/cisco-vpn-and-tunneling.html
dsq_thread_id:
  - 5710049524
tags:
  - Networking
  - SysAdmin

---
And that&#8217;s all I have to say on this matter 😉