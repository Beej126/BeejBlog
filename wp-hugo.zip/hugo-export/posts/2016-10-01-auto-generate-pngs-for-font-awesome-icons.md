---
title: Auto Generate PNG’s for Font Awesome icons
author: Beej
type: post
date: 2016-10-01T17:38:00+00:00
url: /2016/10/auto-generate-pngs-for-font-awesome-icons.html
dsq_thread_id:
  - 5511923853
categories:
  - Uncategorized
tags:
  - Xamarin

---
# &#8230; via PowerShell, using ImageMagick v7

# motivation

comes in handy for Xamarin (Forms) iOS project&#8230; season image filenames & sizes to your taste in the CreateFAImages function