---
title: Canon’s consumer inkjet printer + scanner workhorses
author: Beej
type: post
date: 2008-09-08T17:36:00+00:00
url: /2008/09/excellent-price-on-canon-mp830-printer.html
blogger_bid:
  - 7726907200224433699
blogger_blog:
  - www.beejblog.com
blogger_id:
  - 8354647847692603642
blogger_author:
  - g108669953529091704409
blogger_permalink:
  - /2008/09/excellent-price-on-canon-mp830-printer.html
blogger_thumbnail:
  - http://ak.buy.com/db_assets/prod_lrg_images/557/202367557.jpg
snapEdIT:
  - 1
snapTW:
  - |
    s:199:"a:1:{i:0;a:7:{s:2:"do";s:1:"1";s:9:"msgFormat";s:27:"%TITLE%
    %URL%
    
    %EXCERPT%";s:8:"attchImg";s:1:"1";s:9:"isAutoImg";s:1:"A";s:8:"imgToUse";s:0:"";s:9:"isAutoURL";s:1:"A";s:8:"urlToUse";s:0:"";}}";
categories:
  - Uncategorized
tags:
  - Hardware
  - Printing

---
This is the Canon MP830 that I got two years ago for ~$200:   
<a onblur="try {parent.deselectBloggerImageGracefully();} catch(e) {}" href="http://www.usa.canon.com/consumer/controller?act=ModelInfoAct&fcategoryid=238&modelid=12804" target="_blank"><img style="width: 200px; cursor: pointer" border="0" alt="" src="http://ak.buy.com/db_assets/prod_lrg_images/557/202367557.jpg" /></a>&#160; 

As of 07 Oct 2009 it’s now the MX860 that’s sitting in that slot… progress marches on 🙂   
<a onblur="try {parent.deselectBloggerImageGracefully();} catch(e) {}" href="http://www.usa.canon.com/consumer/controller?act=ProductCatIndexAct&fcategoryid=123" target="_blank"><img style="width: 200px; cursor: pointer" border="0" alt="" src="http://www.usa.canon.com/app/images/mfp/MX850/MX850_586x225.jpg" /></a>&#160; 

As with all this consumer electronics cr_p there’s no guarantees it’ll be all sunshine and daisies…The initial unit I received had some serious problems that can now confidently chalk up to a solid lemon syndrome… I returned it and the _brand new_ replacement I got back has had absolutely zero issues and is still cranking like a champ as of Q4 2009! This model prints very decent photos… not tippy top commercial quality but pretty darn good on glossy paper. Paper seems to matter as much as ink&#8230; I&#8217;ve seen fading on some glossy stock hanging on the wall next to other stock that hasn&#8217;t. &#160; <a href="/2009_10_01_archive.html" target="_blank">Make sure to checkout my Continuous Ink Supply System write up</a>