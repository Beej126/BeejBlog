---
title: What’s this? A pretty decent “Time Machine” built into Win8!?
author: Beej
type: post
date: 2013-08-01T06:45:00+00:00
url: /2013/07/win8-time-machine.html
blogger_bid:
  - 7726907200224433699
blogger_blog:
  - www.beejblog.com
blogger_id:
  - 5121420060832872918
blogger_author:
  - g108669953529091704409
blogger_permalink:
  - /2013/07/win8-time-machine.html
blogger_thumbnail:
  - http://lh6.ggpht.com/-E_DP18yTlyg/UfmhgCq0LYI/AAAAAAAAFT8/oIw66EGADnM/image_thumb%25255B3%25255D.png?imgmax=800
snapEdIT:
  - 1
snapTW:
  - |
    s:199:"a:1:{i:0;a:7:{s:2:"do";s:1:"1";s:9:"msgFormat";s:27:"%TITLE%
    %URL%
    
    %EXCERPT%";s:8:"attchImg";s:1:"1";s:9:"isAutoImg";s:1:"A";s:8:"imgToUse";s:0:"";s:9:"isAutoURL";s:1:"A";s:8:"urlToUse";s:0:"";}}";
dsq_thread_id:
  - 5542126800
categories:
  - Uncategorized
tags:
  - SysAdmin
  - Windows 8+

---
[<img align="right" alt="image" border="0" src="http://lh6.ggpht.com/-E_DP18yTlyg/UfmhgCq0LYI/AAAAAAAAFT8/oIw66EGADnM/image_thumb%25255B3%25255D.png?imgmax=800" height="393" style="background-image: none; border-bottom: 0px; border-left: 0px; border-right: 0px; border-top: 0px; display: inline; float: right; margin: 5px 0px 0px 10px; padding-left: 0px; padding-right: 0px; padding-top: 0px;" title="image" width="646" />][1] 
  
<http://lifehacker.com/5958865/how-to-use-windows-8s-new-file-history-backup-aka-time-machine-for-windows> 
  
i&#8217;ve always considered the Vista/Win7 &#8220;previous versions&#8221; facility to be pretty similar to Time Machine just lacking Apple&#8217;s meticulous care to making it drop dead easy to use. 
  
i hadn&#8217;t yet noticed the MS boys had taken yet another swipe at simplifying the UI in Win8&#8230; i&#8217;m assuming there&#8217;s still a usability gap that the Mac boys can laugh at us, but gee, first impression is &#8220;not bad Balmer you ol’ dog”

  1. search for &#8220;file history&#8221; in win8 home screen 
  2. fire up the ui 
  3. select my backup drive 
  4. click the &#8220;turn on&#8221; button 
  5. in normal explorer window right mouse all my favorite folders and <a href="http://marcoditullio.wordpress.com/2012/10/29/windows-8-file-history-add-custom-folders/" target="_blank">add them to the documents &#8220;library&#8221;</a> &#8211; since that&#8217;s included in what gets backed up (libraries are those fancy pants folder buckets that came along probably with Vista) 
  6. click the &#8220;run now&#8221; link 
  7. click &#8220;restore personal files&#8221; link and yep sure enough all the stuff is piling up out there

defaults to hourly file versions, just like time machine, but can be readily bumped down to minutes in obvious &#8220;advanced settings&#8221; UI if you want, just like time machine. 
  
the restore UI is clean simple and has exactly what I&#8217;d want/expect out of the box&#8230; a standard folder explorer big current time stamped version at the top and previous, next and a big restore button (see attached) 
  
not bad i say, not bad at all&#8230; &#8217;bout f&#8217;ing time.

 [1]: http://lh3.ggpht.com/-Xh2JUo3h_YI/UfmhfMF5ItI/AAAAAAAAFT0/u_K5cJ6GDOs/s1600-h/image%25255B5%25255D.png