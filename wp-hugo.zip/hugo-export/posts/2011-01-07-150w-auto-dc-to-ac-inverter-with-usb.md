---
title: 150W Auto DC to AC Inverter with USB
author: Beej
type: post
date: 2011-01-07T19:54:00+00:00
url: /2011/01/150w-auto-dc-to-ac-inverter-with-usb.html
blogger_bid:
  - 7726907200224433699
blogger_blog:
  - www.beejblog.com
blogger_id:
  - 3164837019545435687
blogger_author:
  - g108669953529091704409
blogger_permalink:
  - /2011/01/150w-auto-dc-to-ac-inverter-with-usb.html
blogger_thumbnail:
  - http://lh3.ggpht.com/_XlySlDLkdOc/TSdvWWpKEHI/AAAAAAAAE2E/Mo2Y4lS45ZA/image%5B3%5D.png?imgmax=800
snapEdIT:
  - 1
snapTW:
  - |
    s:199:"a:1:{i:0;a:7:{s:2:"do";s:1:"1";s:9:"msgFormat";s:27:"%TITLE%
    %URL%
    
    %EXCERPT%";s:8:"attchImg";s:1:"1";s:9:"isAutoImg";s:1:"A";s:8:"imgToUse";s:0:"";s:9:"isAutoURL";s:1:"A";s:8:"urlToUse";s:0:"";}}";
dsq_thread_id:
  - 5753673817
categories:
  - Uncategorized
tags:
  - Hardware

---
Here’s the one I got: <a href="http://www.xoxide.com/150w-acpower-inverter-usb.html" target="_blank"><img style="background-image: none; border-right-width: 0px; padding-left: 0px; padding-right: 0px; display: inline; border-top-width: 0px; border-bottom-width: 0px; border-left-width: 0px; padding-top: 0px" title="image" border="0" alt="image" src="http://lh3.ggpht.com/_XlySlDLkdOc/TSdvWWpKEHI/AAAAAAAAE2E/Mo2Y4lS45ZA/image%5B3%5D.png?imgmax=800" width="204" height="184" /></a> Input: DC 12V   
Output: AC 110-120V, 60Hz, 150W   
&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160; USB DC 5V, 500mA I use it for our camera battery chargers when we go on road trips.   
It&#8217;s a pretty compact arrangement to plug a cam.batt.charger into this and forget about it.   
And it&#8217;s nice to be able to toss our iPods, Smart Phones, etc on the USB port. I&#8217;ve read that charging camera batteries requires more juice than you can get out of USB,   
and that&#8217;s probably why those are all A/C wall plugs only. They don&#8217;t show it in the picture but on the reverse side of the unit is a little 20v _external_ fuse (i.e. easily user serviceable).   
You don&#8217;t always see that kind of feature with these kinds of cheapo things. There&#8217;s actually a little fan in that box which is probably a good thing.   
Unfortunately you can hear it when it cranks up&#8230; it&#8217;s not a deafening noise but you can hear it. I actually don’t like Xoxide that well… they definitely bungled my last order… you might want to source this somewhere else… the model number appears to be “DAU-150”… I can’t identify a manufacturer name anywhere on the outside… Here’s a <a href="http://www.google.com/webhp#q=150w+inverter+usb&hl=en&tbs=shop:1,p_ord:p" target="_blank">Google Search for similar items</a> (inverter is a key word to include in your searches)… there’s plenty of good options out there… Here’s one on <a href="http://cgi.ebay.com/ws/eBayISAPI.dll?ViewItem&item=230517351522#vi-content" target="_blank">eBay that looks just like mine </a>but also sports a dual Euro/US compatible AC socket.