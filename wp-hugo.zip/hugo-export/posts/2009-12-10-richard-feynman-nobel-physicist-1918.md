---
title: Richard Feynman (Nobel Physicist, 1918 – 1988)
author: Beej
type: post
date: 2009-12-10T17:14:00+00:00
url: /2009/12/richard-feynman-nobel-physicist-1918.html
blogger_bid:
  - 7726907200224433699
blogger_blog:
  - www.beejblog.com
blogger_id:
  - 5499594640950065757
blogger_author:
  - g108669953529091704409
blogger_permalink:
  - /2009/12/richard-feynman-nobel-physicist-1918.html
blogger_thumbnail:
  - http://lh4.ggpht.com/_XlySlDLkdOc/SyEsdtukrAI/AAAAAAAAEo4/kALSTBqCgfI/Richard_Feynman%5B3%5D.jpg?imgmax=800
snapEdIT:
  - 1
snapTW:
  - |
    s:199:"a:1:{i:0;a:7:{s:2:"do";s:1:"1";s:9:"msgFormat";s:27:"%TITLE%
    %URL%
    
    %EXCERPT%";s:8:"attchImg";s:1:"1";s:9:"isAutoImg";s:1:"A";s:8:"imgToUse";s:0:"";s:9:"isAutoURL";s:1:"A";s:8:"urlToUse";s:0:"";}}";
dsq_thread_id:
  - 5753670713
categories:
  - Uncategorized
tags:
  - Fun
  - Video

---
<a title="http://en.wikipedia.org/wiki/Richard_Feynman" href="http://en.wikipedia.org/wiki/Richard_Feynman" target="_blank"><img style="border-right-width: 0px; display: inline; border-top-width: 0px; border-bottom-width: 0px; border-left-width: 0px" title="Richard_Feynman" border="0" alt="Richard_Feynman" src="http://lh4.ggpht.com/_XlySlDLkdOc/SyEsdtukrAI/AAAAAAAAEo4/kALSTBqCgfI/Richard_Feynman%5B3%5D.jpg?imgmax=800" width="244" height="182" /></a> Just kinda catching up with how “fun smart” this guy was… worked on the Manhattan project, all kinds of creative physics problem solving, “Original Prophet of Nanotechnology”, Nobel prize in Physics 1965, liked strip clubs, art and bongo drums… there are at least two semi-auto biographies out there in public circulation… I’m reading “Surely You’re Joking, Mr. Feynman!” right now… also a few enjoyable BBC Horizon videos featuring a fair amount of direct interview content: “<a href="http://docuwiki.net/index.php?title=The_Pleasure_of_Finding_Things_Out" target="_blank">The Pleasure of Finding Things Out (1981)</a>”, “[The Quest for Tannu Tuva (1988)][1]” and “<a href="http://docuwiki.net/index.php?title=No_Ordinary_Genius_Richard_Feynman" target="_blank">No Ordinary Genius (1993)</a>”

 [1]: http://docuwiki.net/index.php?title=The_Quest_for_Tannu_Tuva "http://docuwiki.net/index.php?title=The_Quest_for_Tannu_Tuva"