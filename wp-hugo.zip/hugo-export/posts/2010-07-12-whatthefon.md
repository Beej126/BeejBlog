---
title: WhatTheFont ?
author: Beej
type: post
date: 2010-07-13T05:24:00+00:00
url: /2010/07/whatthefon.html
blogger_bid:
  - 7726907200224433699
blogger_blog:
  - www.beejblog.com
blogger_id:
  - 4781349377087742989
blogger_author:
  - g108669953529091704409
blogger_permalink:
  - /2010/07/whatthefont.html
categories:
  - Uncategorized
tags:
  - WebDev

---
[Very very very handy… font lookup by uploading a bitmap example!!][1]

 [1]: http://new.myfonts.com/WhatTheFont/