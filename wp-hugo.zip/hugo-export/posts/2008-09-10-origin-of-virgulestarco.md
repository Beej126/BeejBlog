---
title: The Origin of VirguleStar.com
author: Beej
type: post
date: 2008-09-11T05:26:00+00:00
url: /2008/09/origin-of-virgulestarco.html
blogger_bid:
  - 7726907200224433699
blogger_blog:
  - www.beejblog.com
blogger_id:
  - 8427023106832966820
blogger_author:
  - g108669953529091704409
blogger_permalink:
  - /2008/09/origin-of-virgulestarcom.html
categories:
  - Uncategorized

---
I’m drafting off the idea of expanding geeky punctuation into words (popularized by [www.SlashDot.org][1])   
(<a href="http://en.wikipedia.org/wiki/Slashdot" target="_blank">Funny story behind his originating motivation</a>)   
so SlashDot equals /. 

Based on that, being a comment happy developer, I thought an expansion of /* would be particularly apropos as that’s the well known opening <a href="http://en.wikipedia.org/wiki/Comment_(computer_programming)" target="_blank">comment syntax</a> in languages like C, C++, C#, Java, T-SQL, etc. 

Of course, SlashStar.com and readily desirable derivates were already taken 🙁 … however, browsing for slash synonyms turned up "<a href="http://dictionary.reference.com/browse/virgule" target="_blank">virgule</a>", specifically for the <u>forward</u> slash character, nice!&#8230; yeah ok, it doesn&#8217;t role off the tongue but its obscurity meant I had an available domain name hit and that’s obviously key! 🙂 

And thus www.VirguleStar.com was born.

 [1]: http://www.SlashDot.org