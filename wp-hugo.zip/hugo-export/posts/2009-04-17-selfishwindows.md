---
title: 'Concept: ‘Selfish’ Window Manager aka ‘Greedy Winders’'
author: Beej
type: post
date: 2009-04-18T05:45:00+00:00
url: /2009/04/selfishwindows.html
blogger_bid:
  - 7726907200224433699
blogger_blog:
  - www.beejblog.com
blogger_id:
  - 7393543436742896492
blogger_author:
  - g108669953529091704409
blogger_permalink:
  - /2009/04/selfishwindows.html
dsq_thread_id:
  - 5690973763
categories:
  - Uncategorized

---
Set a priority order on primary app windows like video, email, eBook reader and then they automatically maintain their size, “repel” from overlapping with other windows and z-order themselves to the top with transparency.