---
title: Loading Ice Cream Sandwich (ICS – Android v4.0) on Samsung Galaxy Tab 7.7 (P6800)
author: Beej
type: post
date: 2012-12-19T02:49:00+00:00
url: /2012/12/loading-ice-cream-sandwich-ics-android.html
blogger_bid:
  - 7726907200224433699
blogger_blog:
  - www.beejblog.com
blogger_id:
  - 23231300642328347
blogger_author:
  - g108669953529091704409
blogger_permalink:
  - /2012/12/loading-ice-cream-sandwich-ics-android.html
blogger_thumbnail:
  - http://modmyi.com/attachments/forums/iphone-4-new-skins-themes-launches/555329d1322802429-ice-cream-sandwich-android-4-0-android_ice_cream_sandwich_electronic_bytes.png
snapEdIT:
  - 1
snapTW:
  - |
    s:199:"a:1:{i:0;a:7:{s:2:"do";s:1:"1";s:9:"msgFormat";s:27:"%TITLE%
    %URL%
    
    %EXCERPT%";s:8:"attchImg";s:1:"1";s:9:"isAutoImg";s:1:"A";s:8:"imgToUse";s:0:"";s:9:"isAutoURL";s:1:"A";s:8:"urlToUse";s:0:"";}}";
dsq_thread_id:
  - 5542133839
categories:
  - Uncategorized
tags:
  - Android

---
Links: 

  1. <a href="http://www.theandroidsoul.com/new-galaxy-tab-7-7-gets-clockworkmod-recovery-for-both-3gwifi-edition-and-wifi-only-edition/" target="_blank">ClockWorkMod (CWM)</a> “Recovery” booter for our device &#8211; <a href="http://www.mediafire.com/?045y0s12yamm2u8" target="_blank">Direct link to binary</a> 
  2. The actual ICS ROM (file name &#8211; <a href="http://forum.xda-developers.com/index.php" target="_blank">P6800XXLQ1_ICS_IT168.zip</a>) 
  3. <a href="http://getmd5checker.com/download/latest/Md5Checker.zip" target="_blank">MD5 Checker</a> 

Steps: 

  1. Check model &#8211; First make sure you have the same exact model as me = **GT-P6800**… it will be on the back in small print at the bottom. 
  2. Download the links 
  3. Check ROM file – use MD5 Checker to confirm P6800XXLQ1\_ICS\_IT168.zip checks to 16A167C9 &#8211; 7B1B892D &#8211; BA6884AD – 36434CFE 
  4. Install CWM &#8211; Follow link #1 for install instructions… they’re clear… don’t skim, follow them closely 
  5. Backup &#8211; Boot into CWM menu and do the full backup of your current system. 
  6. Install ICS – Follow link #2 instructions… 
      1. **\*everything\* could be wiped as a result,** so make sure you know where to go reload all your apps!! 
      2. follow steps closely 
      3. one clarification “2) place on internal SD” basically means /sdcard/ on ours… you get to browse for it in CWM so it doesn’t really matter where. 

The tab took forever to reboot back up from the glowing “SAMSUNG” boot logo after the install BUT IT WORKED! 

I’ve had this running since 2012-08-18 and haven’t had a single glitch… this ROM is well in the bag 100% solid no-brainer by all accounts at this point. I hope to load CM10 JellyBean v4.1 or perhaps even CM10.1 v4.2 soon… the one thing that still hasn’t been fixed on those yet is HDMI out (as of 2012-12-18) … and I actually really like using mine as a <a href="http://www.roku.com/" target="_blank">Roku</a> stand-in. 

Good luck!   
<img style="border-left-width: 0px; border-right-width: 0px; background-image: none; border-bottom-width: 0px; padding-top: 0px; padding-left: 0px; padding-right: 0px; border-top-width: 0px" border="0" src="http://modmyi.com/attachments/forums/iphone-4-new-skins-themes-launches/555329d1322802429-ice-cream-sandwich-android-4-0-android_ice_cream_sandwich_electronic_bytes.png" width="215" height="236" />

### [(Back to main GTab7.7 Post)][1]

 [1]: /2012/04/samsung-galaxy-tab-77-p6800.html