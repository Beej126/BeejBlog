---
title: Fantastic ORM details
author: Beej
type: post
date: 2012-01-13T17:49:00+00:00
url: /2012/01/fantastic-orm-details.html
blogger_bid:
  - 7726907200224433699
blogger_blog:
  - www.beejblog.com
blogger_id:
  - 3660982190949581397
blogger_author:
  - g108669953529091704409
blogger_permalink:
  - /2012/01/fantastic-orm-details.html
categories:
  - Uncategorized

---
[http://samsaffron.com/archive/2011/03/30/How+I+learned+to+stop+worrying+and+write+my+own+ORM][1]

 [1]: http://samsaffron.com/archive/2011/03/30/How+I+learned+to+stop+worrying+and+write+my+own+ORM "http://samsaffron.com/archive/2011/03/30/How+I+learned+to+stop+worrying+and+write+my+own+ORM"