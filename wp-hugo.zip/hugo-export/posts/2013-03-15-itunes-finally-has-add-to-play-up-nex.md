---
title: iTunes finally has “add to play up next”
author: Beej
type: post
date: 2013-03-15T06:44:00+00:00
url: /2013/03/itunes-finally-has-add-to-play-up-nex.html
blogger_bid:
  - 7726907200224433699
blogger_blog:
  - www.beejblog.com
blogger_id:
  - 7216070620768375565
blogger_author:
  - g108669953529091704409
blogger_permalink:
  - /2013/03/itunes-finally-has-add-to-play-up-next.html
blogger_thumbnail:
  - http://lh3.ggpht.com/-akLLv-SQqF0/UULDZQ3HNmI/AAAAAAAAFPA/CwAx0dZeN5U/image_thumb%25255B2%25255D.png?imgmax=800
snapEdIT:
  - 1
snapTW:
  - |
    s:199:"a:1:{i:0;a:7:{s:2:"do";s:1:"1";s:9:"msgFormat";s:27:"%TITLE%
    %URL%
    
    %EXCERPT%";s:8:"attchImg";s:1:"1";s:9:"isAutoImg";s:1:"A";s:8:"imgToUse";s:0:"";s:9:"isAutoURL";s:1:"A";s:8:"urlToUse";s:0:"";}}";
categories:
  - Uncategorized
tags:
  - Music

---
WHY did that take till 2013?!?
  
Can’t believe they whacked CoverFlow in iTunes 11… I guess I’ll probably forget how much I liked the full screen CoverFlow eventually but man what a wild judgment call on Apple’s part there.
  
[<img alt="image" border="0" height="386" src="http://lh3.ggpht.com/-akLLv-SQqF0/UULDZQ3HNmI/AAAAAAAAFPA/CwAx0dZeN5U/image_thumb%25255B2%25255D.png?imgmax=800" style="background-image: none; border-bottom-width: 0px; border-left-width: 0px; border-right-width: 0px; border-top-width: 0px; display: inline; padding-left: 0px; padding-right: 0px; padding-top: 0px;" title="image" width="1066" />][1]

 [1]: http://lh3.ggpht.com/-kMo4YkoDze8/UULDYhOO3_I/AAAAAAAAFO4/qneUD8QzNoo/s1600-h/image%25255B4%25255D.png