---
title: Knockout HTML5 Canvas Signature Capture
author: Beej
type: post
date: 2016-03-01T23:19:08+00:00
url: /2016/03/knockout-html5-canvas-signature-capture.html
dsq_thread_id:
  - 5590441451
categories:
  - Uncategorized
tags:
  - Knockout

---
<p data-height="268" data-theme-id="0" data-slug-hash="VaYOxy" data-default-tab="result" data-user="Beej2020" class="codepen">
  See the Pen <a href="http://codepen.io/Beej2020/pen/VaYOxy/">Knockout HTML5 Canvas Signature Capture</a> by Brent Anderson (<a href="http://codepen.io/Beej2020">@Beej2020</a>) on <a href="http://codepen.io">CodePen</a>.
</p>