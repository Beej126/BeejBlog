---
title: LED Projectors
author: Beej
type: post
date: 2009-05-21T09:48:00+00:00
url: /2009/05/led-projectors.html
blogger_bid:
  - 7726907200224433699
blogger_blog:
  - www.beejblog.com
blogger_id:
  - 3666859700010922415
blogger_author:
  - g108669953529091704409
blogger_permalink:
  - /2009/05/led-projectors.html
blogger_thumbnail:
  - http://lh3.ggpht.com/_XlySlDLkdOc/ShVUJw9aiVI/AAAAAAAADQ0/SON-JwOPPeQ/image_thumb%5B1%5D.png?imgmax=800
snapEdIT:
  - 1
snapTW:
  - |
    s:199:"a:1:{i:0;a:7:{s:2:"do";s:1:"1";s:9:"msgFormat";s:27:"%TITLE%
    %URL%
    
    %EXCERPT%";s:8:"attchImg";s:1:"1";s:9:"isAutoImg";s:1:"A";s:8:"imgToUse";s:0:"";s:9:"isAutoURL";s:1:"A";s:8:"urlToUse";s:0:"";}}";
dsq_thread_id:
  - 5542128428
categories:
  - Uncategorized
tags:
  - Hardware
  - Projectors

---
This is THE real wave of the future… Finally, we’ll get to leave the whole stupid bulb replacement game behind!&#160; LED light source has lifespan specs of 20,000 hours!&#160; LED’s are the low temp light source we all love in those nifty new flash lights these days.&#160; Contrast specs will also be a thing of the past, they’re rating this model at 100,000:1!!&#160; Looks like they’re still working on getting the light level output up to snuff, this was only rated at a very anemic 800 lumens… i’m sure that’s only a matter of time as well. Vivitek’s already got a 1080p model out… and it’s only $14k! 🙂 [Endgadget.com’s coverage][1] [ProctorCentral.com’s coverage][2] [<img style="border-bottom: 0px; border-left: 0px; display: inline; border-top: 0px; border-right: 0px" title="image" border="0" alt="image" src="http://lh3.ggpht.com/_XlySlDLkdOc/ShVUJw9aiVI/AAAAAAAADQ0/SON-JwOPPeQ/image_thumb%5B1%5D.png?imgmax=800" width="183" height="135" />][3] Starts to make sense why we’re seeing this technology pop up in the pico projector end of the spectrum at first… low res, low brightness, low power, low footprint all combine for a synergistic package at the moment. [<img style="border-bottom: 0px; border-left: 0px; display: inline; border-top: 0px; border-right: 0px" title="image" border="0" alt="image" src="http://lh4.ggpht.com/_XlySlDLkdOc/ShVUKSjpieI/AAAAAAAADQ4/sYj3nt-LYds/image%5B7%5D.png?imgmax=800" width="244" height="235" />][4] I just bought a bulb technology projector (LCD based Epson Home Cinema 720)… hopefully by the time my bulb is burning out (3 years??) LED projectors will be down to mainstream prices.

 [1]: http://www.engadgethd.com/2009/01/08/viviteks-hc7500a-is-worlds-first-1080p-led-projector/
 [2]: http://www.projectorcentral.com/news_story_1237.htm
 [3]: http://lh6.ggpht.com/_XlySlDLkdOc/ShVUJe-TvvI/AAAAAAAADQw/6IBkl8qeG-s/s1600-h/image%5B3%5D.png
 [4]: http://www.optoma.co.uk/optomapico/PicoIntro.aspx