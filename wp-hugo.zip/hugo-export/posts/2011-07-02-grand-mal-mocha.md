---
title: Grand Mal Mocha
author: Beej
type: post
date: 2011-07-02T17:50:00+00:00
url: /2011/07/grand-mal-mocha.html
blogger_bid:
  - 7726907200224433699
blogger_blog:
  - www.beejblog.com
blogger_id:
  - 4212316342123664215
blogger_author:
  - g108669953529091704409
blogger_permalink:
  - /2011/07/grand-mal-mocha.html
tags:
  - Fun
  - Synthesis

---
