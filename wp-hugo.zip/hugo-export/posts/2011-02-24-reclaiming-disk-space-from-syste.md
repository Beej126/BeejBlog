---
title: Reclaiming disk space from “system volume information”
author: Beej
type: post
date: 2011-02-24T13:36:00+00:00
url: /2011/02/reclaiming-disk-space-from-syste.html
blogger_bid:
  - 7726907200224433699
blogger_blog:
  - www.beejblog.com
blogger_id:
  - 8729692388031732220
blogger_author:
  - g108669953529091704409
blogger_permalink:
  - /2011/02/reclaiming-disk-space-from-system.html
tags:
  - SysAdmin

---
<a href="http://indrajitc.wordpress.com/2008/03/25/reclaiming-disk-space-from-system-volume-information/" target="_blank">This sums it up very well</a> Don’t forget to run the VSSAdmin commands under a 64bit CMD.exe if you’re on 64bit Windows. I know that sounds obvious but I run something called <a href="http://jpsoft.com/tccle_cmd_replacement.html" target="_blank">TakeCommand Console LE</a> which is a great shell but the free version is 32bit only.