---
title: Windows File Explorer auto extract zips like Mac Finder
author: Beej
type: post
date: 2018-02-15T21:12:37+00:00
url: /2018/02/windows-file-explorer-auto-extract-zips-like-mac-finder.html
dsq_thread_id:
  - 6482473441
categories:
  - Uncategorized
tags:
  - Productivity
  - SysAdmin

---
