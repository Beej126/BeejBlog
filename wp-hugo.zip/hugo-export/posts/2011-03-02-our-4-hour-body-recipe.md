---
title: Our 4-Hour Body Recipe
author: Beej
type: post
date: 2011-03-02T23:30:00+00:00
url: /2011/03/our-4-hour-body-recipe.html
blogger_bid:
  - 7726907200224433699
blogger_blog:
  - www.beejblog.com
blogger_id:
  - 2742434256569645137
blogger_author:
  - g108669953529091704409
blogger_permalink:
  - /2011/03/our-4-hour-body-recipe.html
blogger_thumbnail:
  - http://lh3.ggpht.com/_XlySlDLkdOc/TW5ifwg1olI/AAAAAAAAE5Q/xLCgSMB9kAc/image%5B2%5D.png?imgmax=800
snapEdIT:
  - 1
snapTW:
  - |
    s:199:"a:1:{i:0;a:7:{s:2:"do";s:1:"1";s:9:"msgFormat";s:27:"%TITLE%
    %URL%
    
    %EXCERPT%";s:8:"attchImg";s:1:"1";s:9:"isAutoImg";s:1:"A";s:8:"imgToUse";s:0:"";s:9:"isAutoURL";s:1:"A";s:8:"urlToUse";s:0:"";}}";
dsq_thread_id:
  - 5542135694
categories:
  - Uncategorized
tags:
  - Life

---
<a title="Link to Amazon" href="https://www.amazon.com/dp/030746363X/ref=as_li_tf_til?tag=httpwwwbeejbl-20&camp=0&creative=0&linkCode=as1&creativeASIN=030746363X&adid=10169PK7PCC18R0XGR78&" target="_blank"><img title="Link to Amazon" style="border-left-width: 0px; border-right-width: 0px; background-image: none; border-bottom-width: 0px; float: right; padding-top: 0px; padding-left: 0px; display: inline; padding-right: 0px; border-top-width: 0px" border="0" alt="Link to Amazon" align="right" src="http://lh3.ggpht.com/_XlySlDLkdOc/TW5ifwg1olI/AAAAAAAAE5Q/xLCgSMB9kAc/image%5B2%5D.png?imgmax=800" width="251" height="325" /></a> Ferris gets right to his go-to Mexican oriented mix pretty quick into the fat loss section of the book… it’s very quick reading to pick up his basic approach.&nbsp;&nbsp; Here’s how we’ve taken that and made it our own:

  * Full Size White Onion chopped up (probably any kind of onion will do) 
      * Full Size Tomato chopped up 
          * Full Green or Red Bell Pepper chopped up 
              * Can of Black Beans (pinto and kidney work as well of course… we just really like black beans) 
                  * Grilled Large Chicken Breast </ul> 
                Those items are all basically on a 1:1 ratio. _**5**_ of each fills our 6 quart “stock pot”, which will last the two of us through a work week. Along with those primary stock items, we also flavor in some diced garlic… I love garlic, I go kind of nuts with it. To spice it up, I do a full 16 oz. jar of Vlasic _**hot**_ pepper rings (what I call pepperoncini&#8217;s)&nbsp; -AND- a full 12 oz. jar of sliced hot jalapenos… including the juice from both (keep an eye out for corn syrup here)… those give it a fun kick… which should also help manage appetite. I think you’d want the full 5x of everything else to take on those full jars of spiciness… please start out with less until you find your preferred balance. To help freshen up each reheated serving, we melt in some grated cheese (keep it very minimal since this is on the avoid list), then toss on a dollop of sour cream and some avocado slices. Tim gives pointers on what to avoid just as much as what to embrace… pretty much all fruit sugars are on the avoid list, no big surprise. Another is to avoid many things that are white due to flour or starch, which is also a fairly common thread of advice from other dietary sources. It’s nice to load up the digital version of the book and hit the hyperlinks to the references… the weight tracking spreadsheet, etc. Good luck with your goals and have fun! 🙂 <img title="Getting Started" style="border-left-width: 0px; border-right-width: 0px; background-image: none; border-bottom-width: 0px; padding-top: 0px; padding-left: 0px; display: inline; padding-right: 0px; border-top-width: 0px" border="0" alt="" src="http://lh5.ggpht.com/_XlySlDLkdOc/TXPEGvWTlSI/AAAAAAAAE48/XykcMElylvk/P1060007_thumb%5B3%5D.jpg?imgmax=800" width="356" height="278" /><img title="Full Pot!" style="border-left-width: 0px; border-right-width: 0px; background-image: none; border-bottom-width: 0px; padding-top: 0px; padding-left: 0px; display: inline; padding-right: 0px; border-top-width: 0px" border="0" alt="" src="http://lh5.ggpht.com/_XlySlDLkdOc/TXPEIMD5IRI/AAAAAAAAE5E/St9FWhlWyHE/P1060021_thumb%5B2%5D.jpg?imgmax=800" width="363" height="278" />