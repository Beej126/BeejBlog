---
title: Trailer Hitch Bike Rack
author: Beej
type: post
date: 2013-05-01T22:45:00+00:00
url: /2013/05/trailer-hitch-bike-rack.html
blogger_bid:
  - 7726907200224433699
blogger_blog:
  - www.beejblog.com
blogger_id:
  - 3858609544428341335
blogger_author:
  - g108669953529091704409
blogger_permalink:
  - /2013/05/trailer-hitch-bike-rack.html
blogger_thumbnail:
  - http://lh6.ggpht.com/-fN2AO5a_6OU/UYGeHcI_Y0I/AAAAAAAAFPo/IJeakBc3Q2M/440%25255B5%25255D.jpg?imgmax=800
snapEdIT:
  - 1
snapTW:
  - |
    s:199:"a:1:{i:0;a:7:{s:2:"do";s:1:"1";s:9:"msgFormat";s:27:"%TITLE%
    %URL%
    
    %EXCERPT%";s:8:"attchImg";s:1:"1";s:9:"isAutoImg";s:1:"A";s:8:"imgToUse";s:0:"";s:9:"isAutoURL";s:1:"A";s:8:"urlToUse";s:0:"";}}";
dsq_thread_id:
  - 5542131100
categories:
  - Uncategorized
tags:
  - Biking
  - Hardware
  - Outdoors

---
<a href="http://www.etrailer.com/tv-demo-softride-element-SR26248.aspx" target="_blank"><img title="440" style="border-left-width: 0px; border-right-width: 0px; background-image: none; border-bottom-width: 0px; float: left; padding-top: 0px; padding-left: 0px; margin: 0px 11px 10px 0px; display: inline; padding-right: 0px; border-top-width: 0px" border="0" alt="440" align="left" src="http://lh6.ggpht.com/-fN2AO5a_6OU/UYGeHcI_Y0I/AAAAAAAAFPo/IJeakBc3Q2M/440%25255B5%25255D.jpg?imgmax=800" width="473" height="380" /></a> After fair amount of homework, went with the <a href="http://www.etrailer.com/tv-demo-softride-element-SR26248.aspx" target="_blank">Softride “Element”</a> 4-bike rack… pricing is consistently $210’ish and I went with my local <a href="http://www.rei.com/product/854829/softride-element-4-bike-hitch-rack" target="_blank">REI</a> for solid local support. Was torn between this Element and the $70 more big brother “<a href="http://www.etrailer.com/Hitch-Bike-Racks/Softride/SR26247.html" target="_blank">Dura</a>” model… which adds “anti-sway cradels” (i.e. seat tube rubber wraps) + built in lockup cable + hitch bolt lock + beefier + 5 lbs… I’m thinking I’ll be good at rigging my own anti sway (via old inner tubes & bungees), the rest really didn’t appeal to me and (I presume since we chose the low end 4 cyl. Kia Sportage for it’s gas mileage) I was unpleasantly surprised to discover that I have to use the 1-1/4” hitch extender &#8211; so the less weight/torque the better. Notable feature of the Softride line is its _parallelogram_ bars that keep the bikes perpendicular to the ground when you lean the rack away to open your lift gate&#8230; Yakima/Thule hasn&#8217;t copied that yet… and the only other means for simple tail gate access out there are $600 plus “swing away” style that really look clunky to me. If this sounds useless to you, fine but I feel like it&#8217;s &#8220;last inch&#8221; convenience like that which helps things slump over the swear words threshold when you just want to get something out quickly and get going. There are a couple higher end models to be aware of if you’ve got cash to burn: a lighter <a href="http://www.etrailer.com/Hitch-Bike-Racks/Softride/SR26428.html" target="_blank">aluminum</a> one and a hydraulic <a href="http://www.etrailer.com/Hitch-Bike-Racks/Softride/SR26321.html" target="_blank">Assist</a> model that helps raise back into locked position… cool but my sweet spot is lower end. The Softride’s are a great price against the field&#8230; one can easily hit $300, $400 , $600 for no great reason&#8230; I&#8217;ve read a lot about these on Amazon etc and am thoroughly prepped to be careful/creative with rubber straps that seem to be highly prone to tearing … but the metal parts and basic functionality are reported solid across the board.