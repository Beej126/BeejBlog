---
title: Unprotect MS Word Document
author: Beej
type: post
date: 2009-06-22T15:15:00+00:00
url: /2009/06/unprotect-ms-word-documen.html
blogger_bid:
  - 7726907200224433699
blogger_blog:
  - www.beejblog.com
blogger_id:
  - 951508512400721331
blogger_author:
  - g108669953529091704409
blogger_permalink:
  - /2009/06/unprotect-ms-word-document.html
dsq_thread_id:
  - 6068551357
categories:
  - Uncategorized

---
  * <a href="http://shaikhsohail.wordpress.com/2008/09/27/how-to-crack-unprotect-or-remove-document-protection-in-word/" target="_blank">Here’s the gist</a> – fire up Word, open your file, then select Tools > Macro > “Microsoft Script Editor”, you’ll get an HTML view, search for “UnprotectPassword” and change it to all zero’s – voila!
  * I had to un-check IE > Tools > Internet Options > Advanced > Disable Script Debugging (other) to get the MSE menu item in MS Word enabled.
  * MSE exe location on my system (Office 2003) -&#160; C:Program FilesMicrosoft OfficeOFFICE11MSE7.exe