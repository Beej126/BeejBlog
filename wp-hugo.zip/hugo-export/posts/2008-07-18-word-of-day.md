---
title: Word of the Day – Meretricious
author: Beej
type: post
date: 2008-07-18T08:24:00+00:00
url: /2008/07/word-of-day.html
blogger_bid:
  - 7726907200224433699
blogger_blog:
  - www.beejblog.com
blogger_id:
  - 4601071822670604656
blogger_author:
  - g108669953529091704409
blogger_comments:
  - 2
blogger_permalink:
  - /2008/07/word-of-day.html
dsq_thread_id:
  - 5508631581
tags:
  - Fun

---
Adjective: meretricious \`meri&#8217;treeshus
  
1. Tastelessly showy
  
&#8220;a meretricious yet stylish book&#8221;
  
2. Based on pretense; deceptively pleasing
  
&#8220;meretricious praise&#8221;; &#8220;a meretricious argument&#8221;
  
3. [archaic] Like or relating to a prostitute
  
&#8220;meretricious relationships&#8221;