---
title: Samsung Q1U-V Ultra Mobile PC (UMPC)
author: Beej
type: post
date: 2008-08-31T09:29:00+00:00
url: /2008/08/samsung-q1u-umpc.html
blogger_bid:
  - 7726907200224433699
blogger_blog:
  - www.beejblog.com
blogger_id:
  - 499379809394399260
blogger_author:
  - g108669953529091704409
blogger_comments:
  - 9
blogger_permalink:
  - /2008/08/samsung-q1u-umpc.html
blogger_thumbnail:
  - http://ak.buy.com/db_assets/large_images/604/204996604.jpg
snapEdIT:
  - 1
snapTW:
  - |
    s:174:"a:1:{i:0;a:6:{s:2:"do";s:1:"1";s:10:"SNAPformat";s:27:"%TITLE%
    %URL%
    
    %EXCERPT%";s:8:"attchImg";s:1:"1";s:9:"isAutoImg";s:1:"A";s:8:"imgToUse";s:0:"";s:4:"doTW";s:1:"1";}}";
dsq_thread_id:
  - 5508631585
categories:
  - Uncategorized
tags:
  - eReading
  - Hardware
  - Mapping

---
[Update: 5 April 2012] Just popped for a <a href="/2012/04/samsung-galaxy-tab-77-p6800.html" target="_blank">Samsung Galaxy Tab 7.7</a>. Loving it. Took a while to find a worthy successor to the Q1U. Way to go Samsung. UPDATE [19 Aug 2009]: Windows 7 totally rocks on this thing!!! At least as peppy as XP, probably better.   
<a onblur="try {parent.deselectBloggerImageGracefully();} catch(e) {}" href="http://ak.buy.com/db_assets/large_images/604/204996604.jpg"><img style="border-right-width: 0px; width: 400px; border-top-width: 0px; border-bottom-width: 0px; border-left-width: 0px; cursor: pointer" border="0" alt="" src="http://ak.buy.com/db_assets/large_images/604/204996604.jpg" /></a>&#160;&#160; [<img style="border-right-width: 0px; border-top-width: 0px; border-bottom-width: 0px; border-left-width: 0px" border="0" alt="Snap1" src="http://lh3.ggpht.com/_XlySlDLkdOc/SXYXrlVOS_I/AAAAAAAACrs/qSZDftGMJzk/Snap1_thumb%5B4%5D.jpg?imgmax=800" width="526" height="404" />][1] 

<ul style="margin-left: 20px">
  <li>
    Buy.com has some more good <a href="http://www.buy.com/prod/samsung-np-q1u-600-q1-ultra-umpc-elxp-a100-600mhz-1gb-40gb-7-wsvga-wl/q/loc/101/204996604.html">photos</a> **AT THE BOTTOM**
  </li>
  <li>
    <a title="http://picasaweb.google.com/Beej2020/SamsungQ1UV#" href="http://picasaweb.google.com/Beej2020/SamsungQ1UV#">some of my own photos</a>
  </li>
  <li>
    <a href="http://www.samsung.com/us/consumer/subtype/subtype.do?group=computersperipherals&type=mobilecomputing&subtype=ultramobilepcs">Samsung&#8217;s Q1U landing page</a>
  </li>
  <li>
    (Interesting, they _just_ (Sept. 19th, 2008) withdrew their links for the Vista model that I got &#8211;for obvious reasons&#8211; looks like the new "Premium" model with a beefier CPU is the currently promoted Vista solution)
  </li>
</ul>

<a href="http://www.samsung.com/us/consumer/detail/support.do?group=computersperipherals&type=mobilecomputing&subtype=ultramobilepcs&model_nm=NP-Q1U&language=&cate_type=all&dType=D&mType=DR&vType=&prd_ia_cd=05010100&disp_nm=Q1U-XP&model_cd=NP-Q1U/000/SEA&menu=download" target="_blank">Samsung Software & Drivers Page</a> 

Specs on the model I got: 

<table style="border-collapse: collapse; margin-left: 10px" border="0" cellspacing="0" cellpadding="1">
  <tr>
    <td>
      Model
    </td>
    
    <td>
      Samsung Q1U-V (NP-Q1UA000) (<a href="http://www.samsung.com/us/system/consumer/product/2008/04/29/np_q1ua000sea/Q1Ultra_DataSheet_080907.pdf">official spec PDF</a>)
    </td>
  </tr>
  
  <tr>
    <td>
      Weight
    </td>
    
    <td>
      1.52 lbs
    </td>
  </tr>
  
  <tr>
    <td>
      Display
    </td>
    
    <td>
      7" 1024 x 600 touch screen LCD (nicely bright)
    </td>
  </tr>
  
  <tr>
    <td>
      Standard Battery
    </td>
    
    <td>
      4-cell Li-Ion Battery, 29.6wh Capacity (rated ~4.5 hours) (6 cells available)
    </td>
  </tr>
  
  <tr>
    <td>
      OS
    </td>
    
    <td>
      Windows 7 absolutely rocks on this thing!!!
    </td>
  </tr>
  
  <tr>
    <td>
      Dimensions
    </td>
    
    <td>
      8.96" x 4.88" x 0.93" (think of a letter size sheet of paper, portrait orientation, folded in half, top to bottom)
    </td>
  </tr>
  
  <tr>
    <td>
      HD
    </td>
    
    <td>
      60GB 1.8” 4200rpm PATA ZIF (<a href="http://sdd.toshiba.com/main.aspx?Path=StorageSolutions/1.8-inchHardDiskDrives/MK6008GAH" target="_blank">Toshiba MK6008GAH</a>)
    </td>
  </tr>
  
  <tr>
    <td>
      WiFi
    </td>
    
    <td>
      802.11 b/g (<a href="http://www.atheros.com/pt/AR5006XS.htm" target="_blank">Atheros AR5006X specs</a>, <a href="http://www.x-drivers.com/catalog/drivers/wireless_networks/companies/atheros/models/ar5001x/12162.html" target="_blank">drivers</a>)
    </td>
  </tr>
  
  <tr>
    <td>
      Wired Ethernet
    </td>
    
    <td>
      10/100 Base TX
    </td>
  </tr>
  
  <tr>
    <td>
      Bluetooth
    </td>
    
    <td>
      Bluetooth® 2.0 + EDR
    </td>
  </tr>
  
  <tr>
    <td>
      USB
    </td>
    
    <td>
      2 x USB 2.0
    </td>
  </tr>
  
  <tr>
    <td>
      CPU
    </td>
    
    <td>
      Intel® Ultra Mobile A110 800MHz clock 512Kb L2 cache/400 MHz FSB
    </td>
  </tr>
  
  <tr>
    <td>
      Video Chipset
    </td>
    
    <td>
      Intel GMA950, 128MB shared memory (<a href="http://www.intel.com/products/chipsets/gma950/index.htm" target="_blank">specs</a>)
    </td>
  </tr>
  
  <tr>
    <td>
      System Memory
    </td>
    
    <td>
      1GB DDR2 400MHz stock (upgraded to 2GB)
    </td>
  </tr>
  
  <tr>
    <td>
      Memory slot
    </td>
    
    <td>
      SD/MMC
    </td>
  </tr>
  
  <tr>
    <td>
      Audio
    </td>
    
    <td>
      HD Audio, SRS TruSurround Sound
    </td>
  </tr>
  
  <tr>
    <td>
      Cameras
    </td>
    
    <td>
      Front facing low res web cam & rear facing video & still (1.3MP)
    </td>
  </tr>
  
  <tr>
    <td>
      Speakers
    </td>
    
    <td>
      2 x 1.5 Watts
    </td>
  </tr>
  
  <tr>
    <td>
      VGA 15 pin out
    </td>
    
    <td>
      Max resolution 2048 x 1536 (nice)
    </td>
  </tr>
  
  <tr>
    <td>
      Headphone out
    </td>
    
    <td>
      Yes
    </td>
  </tr>
  
  <tr>
    <td>
      Microphone
    </td>
    
    <td>
      Dual Array
    </td>
  </tr>
  
  <tr>
    <td>
      RJ45 (LAN)
    </td>
    
    <td>
      YES
    </td>
  </tr>
  
  <tr>
    <td>
      Warranty
    </td>
    
    <td>
      1 Year Parts and Labor
    </td>
  </tr>
  
  <tr>
    <td>
      Fingerprint Reader
    </td>
    
    <td>
      NO
    </td>
  </tr>
</table>

Update [29 Oct 2008]: Unfortunately my touch screen went all whacky, _exactly_ like I&#8217;ve read about:

  * A Samsung rep (apparently) even fesses up to a bad batch of screens: <a href="http://origamiproject.com/forums/2/25383/ShowThread.aspx" target="_blank">Q1 Ultra Screen Issues</a>&#160; 
  * <a href="http://origamiproject.com/forums/1/24846/ShowThread.aspx" target="_blank">Problem with screen in Q1 Ultras</a> 
  * Mine went bad on me while I was using it quietly on my desk&#8230; tried everything suggested with calibration tools&#8230; small improvements but nothing usable 
  * Could&#8217;ve been due to cramming it in a tight backpack through airport few days prior so I&#8217;ll be a little more delicate with the new one 
  * Servicing seems to be very speedy, turnaround is days not weeks&#8230; waiting for it now&#8230; will advise 

Update [12 Nov 2008]: Servicing totally fixed the touch screen tracking problem.

  * They even went ahead and loaded the Samsung XP image rather than bothering with Vista 
  * And swapped out the "Designed for Windows \___" sticker, nice touch. 
  * Turnaround time was excellent. 
  * It is definitely a new screen, old one had a telltale scratch on it &#8230; very nice to ditch that in the process. 

Highlights:

  * I was a little surprised to realize the Q1U-"V" does NOT have the fingerprint reader ([official spec sheet from Samsung][2] breaks down the differences pretty well if you look closely) &#8230; kindof a bummer from a lost/security standpoint but fortunately this isn&#8217;t really where I plan to leave any "life data" anyway 
  * Stock 4-cell, ~4.5 hr battery seems to get right to that mark if you&#8217;re not doing WiFi&#8230; I&#8217;ve since ordered 2 of the 6-cells so I can roll through a big/hike w/o concern 
  * Going in/out of sleep mode is very instantaneous 
  * Vista just kept going off into wait cursor lala land too often so I flipped it over to XP Tablet after a couple days of usage just like everybody else 
  * You definitely wind up waiting on Vista for everything&#8230; as an IT guy it amazes me it ran as well as it did in 1GB of RAM on such a small CPU&#8230; I can&#8217;t imagine an average consumer actually putting up with this configuration though 
  * Power slider switch doubles as full system input lock so you can&#8217;t accidentally bump anything while it&#8217;s on &#8230; very cool usability feature that goes to show Samsung engineers put some real usage design thought into this bugger 
  * Watching a typical AVI movie over WiFi via VLC works like a champ under XP&#8230; Vista could barely pull it off. 
  * The screen is great &#8230; super bright&#8230; you can see all normal Windows widgets at the native 1024 x 600 resolution &#8230; you definitely need the stylus to hit normal sized Windows widgets (min/max/close, scroll bar, etc.)&#8230; fingers work for bigger stuff or widgets not next to another &#8230; the Microsoft "Touch Pack" has a "Touch Improvements" tweak that makes the scroll bars double wide so you have a chance at hitting them with a finger&#8230; that&#8217;s a nice "touch" 😉 
  * It does have a little heat to exhaust&#8230; nothing like a laptop of course&#8230; there&#8217;s actually a little fan in there&#8230; but it&#8217;s absolutely silent 
  * Last but not least, it fits very well as an eReader: 
      * 1.5lbs is very doable… holding it up to read from the lying down position definitely works 
      * Adobe Reader has some nice features I never realized.. it&#8217;ll rotate the page so that rather than rotating the whole Windows Vista desktop (which is way slow) I can just rotate the document in Reader so that portrait viewing utilizes the longest dimension, awesome! 
      * You can also flip Reader into full screen mode to get rid off all scroll/nav bars/buttons and take advantage of full real-estate&#8230; 
      * a test Macworld PDF was fairly readable a full page at a time&#8230; shrinking an 8.5 x 11 inch page of text down by at least 50% while technically readable, would probably cause eye strain after prolonged reading at that size&#8230; 
      * what works quite well is to zoom in to 125% and simply use a finger to drag the page into view as one reads&#8230; it&#8217;s very usable and intuitive this way 
      * I am VERY glad I didn&#8217;t cave in for a cheaper unit in the popular 4"-5" screen size category (Nokia n810, etc.)&#8230; this is absolutely the smallest you could work with for reading full pages&#8230; and honestly, a little bigger (9"??) would not go to waste. 

     <br />These units have been out since late 2006 in various models so there's a nice amount of solid info out there.&#160; The reviews from a year ago when it was nearly twice the price were a little more scathing... it's a tricky product genre to review because peoples' expectations are all over the board in this new of a niche.&#160; If you read between the lines and focus on what you want they stack up pretty darn good... Everybody immediately recognizes that Vista is a too much for these baby CPUs... and just like everybody else, I dropped back to XP Tablet and it runs great.&#160; Don't forget to load up XPLite and trim it all down to the bare minimum.     <br />    <br />I see basically <strike>three</strike> four generations out there:  <ol>   <li>1st gen = the original Q1 (distinguished by no keyboard on the side panels)... basically old enough to scare me away </li>    <li>2nd gen = Q1U (U = Ultra) – this is what I'm most interested in... comes in several configurations ... the biggest difference is that the cheapest &quot;EL&quot; model does NOT have the Bluetooth, Camera or SD slot that all the others do... otherwise the others vary by presence of fingerprint reader and hard drive size (40/60/80 GB) </li>    <li>3rd gen = Q1U-P (Ultra Premium) – significantly more expensive but comes with the most hardware pre-loaded (faster CPU, 2GB RAM (an easy upgrade for the Q1U), a high speed cellular card (also a doable upgrade for the previous model), etc) … a year has now passed and I’m seeing refurbished Premuim models going for $700 range. </li>    <li>4th gen = Q1EX-71G – this seems to have come out Q3/4 2009… 1.2GHz Via Nano U2500 CPU, 2GB RAM stock, SiRF Star GPS (missing from shipping models!?! :(, no keys = <a href="http://www.amazon.com/s/ref=nb_sb_noss?url=search-alias%3Daps&amp;field-keywords=samsung+q1ex&amp;x=0&amp;y=0" target="_blank">$522 on Amazon 07 Sep 2010</a>. Damn, doesn’t look like the GPS made it into production units :( And looks like they changed the dang battery form factor (different SKUs). </li> </ol>  <br />Notable Accessories   <br />  <table style="margin-top: 5px; border-collapse: collapse" border="1" cellpadding="10"><tbody>     <tr>       <td>         RAM-Mounts handlebar mount          <a href="http://www.gpscity.com/ram-mount-strap-rail-base-with-standard-arm-round-assembly.html" target="_blank"><img style="border-right-width: 0px; display: inline; border-top-width: 0px; border-bottom-width: 0px; border-left-width: 0px" title="ramb108u" border="0" alt="ramb108u" src="http://lh3.ggpht.com/_XlySlDLkdOc/TIZ16X-HzeI/AAAAAAAAEwc/uoZCgA_9z6I/ramb108u%5B3%5D.jpg?imgmax=800" width="160" height="160" /></a>        </td>        <td valign="top">         <br /><a href="http://www.ram-mount.com/mount/samsung_q1_ultra_mount.htm">RAM Mounts</a> is mounting nirvana... all kinds of mounting parts to perch this tablet on a ball pivot above bicycle handlebars, etc.           <br />          <br />Both of these RAM-Mounts parts are absolutely top notch.&#160; <br />I ABSOLUTELY LOVE HOW THESE STAND UP TO REAL BANGING ON THE ROAD.</td>     </tr>      <tr>       <td>         RAM-Mounts custom cradle             <br /><a href="http://www.gpscity.com/ram-mount-samsung-q1-ultra-umpc-cradle.html" target="_blank"><img style="border-right-width: 0px; display: inline; border-top-width: 0px; border-bottom-width: 0px; border-left-width: 0px" title="RAM-HOL-SAM2U" border="0" alt="RAM-HOL-SAM2U" src="http://lh4.ggpht.com/_XlySlDLkdOc/Sqi15jrJGAI/AAAAAAAAEk4/jB52wrx4k1g/RAM-HOL-SAM2U%5B4%5D.png?imgmax=800" width="240" height="156" /></a>        </td>        <td valign="top"><a href="http://www.gpscity.com" target="_blank">GPSCity</a> has been very good with solid inventory, fast shipment and competitive prices on the whole RAM production line… they have a nice body of customer reviews to get a good feel for how most parts stand up in real usage.           <br />          <br />Make sure to search for shopping cart discount codes.           <br />This one gave me 10% off: RAMGUF5285</td>     </tr>      <tr>       <td><a href="http://www.amazon.com/gp/product/B004BLIMOU/ref=pd_lpo_k2_dp_sr_2?pf_rd_p=1278548962&amp;pf_rd_s=lpo-top-stripe-1&amp;pf_rd_t=201&amp;pf_rd_i=B0041O200O&amp;pf_rd_m=ATVPDKIKX0DER&amp;pf_rd_r=11TDP6DKDC7P7RMTSEKN" target="_blank"><img style="background-image: none; border-right-width: 0px; padding-left: 0px; padding-right: 0px; display: inline; border-top-width: 0px; border-bottom-width: 0px; border-left-width: 0px; padding-top: 0px" title="image" border="0" alt="image" src="http://lh6.ggpht.com/_XlySlDLkdOc/TWpLx0SUFKI/AAAAAAAAE3s/Yu2z1DC3zcg/image%5B5%5D.png?imgmax=800" width="406" height="171" /></a></td>        <td valign="top">These are a great development for us tableteers… basically nano sized USB dongles that take a micro SD card into them and present very little profile to get whacked around on a mobile device where you need some more easy space.</td>     </tr>      <tr>       <td>         Sierra Wireless MC8781          HPDSA/3G Cell Modem + GPS          <a href="http://shop.ebay.com/?_nkw=SIERRA+MC8781" target="_blank"><img style="border-right-width: 0px; display: inline; border-top-width: 0px; border-bottom-width: 0px; border-left-width: 0px" title="SierraWireless_MC8781" border="0" alt="SierraWireless_MC8781" src="http://lh5.ggpht.com/_XlySlDLkdOc/Sqi16H9wkoI/AAAAAAAAEk8/gu0ZD4bksww/SierraWireless_MC8781%5B7%5D%5B1%5D.png?imgmax=800" width="227" height="191" /></a>        </td>        <td valign="top">Going after one of these now…          <br />          <br />          <ul>           <li>UPDATE [09 Sep 2009]: my GPS experience has been a bust so far on this one… make sure you have specific antennas nailed down… i got the small U-shaped one first… it got HSPA bars outdoors (Vodafone Germany) but nothing on GPS… picked up two more designed for a unit with more internal room… worked well even got signal indoors when giant antenna was just lying in open air but destroyed the GPS signal improvement while cramming it inside… i’d recommend getting one of the external USB sticks that have this same chip… then the antenna comes along for free </li>         </ul>          <ul>           <li><a href="http://www.sierrawireless.com/product/em_comparison.aspx" target="_blank">Model family specs comparison</a> </li>            <li>I’m thinking that “gpsOne” facility is worth going after </li>            <li><a href="http://himax60.blogspot.com/2008/01/my-q1u-gets-hsdpa.html" target="_blank">Someone that&#160; installed the mc8775 model in same exact tablet model as mine</a> </li>            <li><a href="http://forums.whirlpool.net.au/forum-replies-archive.cfm/1108594.html" target="_blank">Firmware and instructions for activating the GPS functionality</a> </li>            <li><a href="http://www.kaskus.us/showthread.php?s=9a4b2b54b08499801a3906260362d4ee&amp;t=1155572&amp;page=12" target="_blank">Good installed pics</a> at this forum </li>         </ul>          &#160;          <ul>           <li>Been using the external <a href="https://buy.garmin.com/shop/shop.do?pID=423" target="_blank">Garmin 10x Bluetooth receiver</a> unit this whole year and it’s served me well but Bluetooth connections are annoyingly flakey sometimes and I’d love to lose the external fob finally. </li>         </ul>          <a href="http://lh6.ggpht.com/_XlySlDLkdOc/SoBuG7AqflI/AAAAAAAAEkU/FUaanHNj0uE/s1600-h/image%5B6%5D.png"><img style="border-right-width: 0px; display: inline; border-top-width: 0px; border-bottom-width: 0px; border-left-width: 0px" title="image" border="0" alt="image" src="http://lh5.ggpht.com/_XlySlDLkdOc/SoBuHKAg4JI/AAAAAAAAEkY/HUORpKYWmLw/image_thumb%5B3%5D.png?imgmax=800" width="87" height="69" /></a>        </td>     </tr>      <tr>       <td align="center"><a href="http://www.bixnet.com/unpowbat.html">Super High Capacity Universal External Battery Pack - BP150             <br /><img style="border-right-width: 0px; display: inline; border-top-width: 0px; border-bottom-width: 0px; border-left-width: 0px" title="laptopupgrade_2067_1399911" border="0" alt="laptopupgrade_2067_1399911" src="http://lh5.ggpht.com/_XlySlDLkdOc/SpJoQiLYSqI/AAAAAAAAEkg/Li9Pi7K6HdE/laptopupgrade_2067_1399911_thumb.gif?imgmax=800" width="200" height="156" />             <br /><img style="border-right-width: 0px; display: inline; border-top-width: 0px; border-bottom-width: 0px; border-left-width: 0px" title="Connector-big-c2" border="0" alt="Connector-big-c2" src="http://lh4.ggpht.com/_XlySlDLkdOc/SpJoRpOXgoI/AAAAAAAAEwM/24j1XisuB7c/Connectorbigc2%5B3%5D.jpg?imgmax=800" width="343" height="256" /> </a></td>        <td valign="top">         <ul>           <li>Samsung stock AC charging brick DC-out = 19V, 3.15A </li>            <li>Samsung stock batteries are rated (both still available on eBay for around $40-$45 as of March 2011)              <ul>               <li>4 Cell = 29.6Wh, 7.4V, 7800mAH (Product ID: AA-PL1UC4B) </li>                <li>6 Cell = 57.7Wh (Product ID: AA-PL1UC6B) </li>             </ul>           </li>         </ul>          <br />          <ul>           <li>This BP150 is rated at 153 Watt-Hours </li>            <li>3lbs is obviously something consider…very doable for a bike, annoying for a backpack </li>            <li>At $200 this one is much more bang for the buck than <a href="http://www.samsung.com/us/consumer/detail/accessories.do?group=computersperipherals&amp;type=mobilecomputing&amp;subtype=ultramobilepcs&amp;model_cd=NP-Q1U/000/SEA#" target="_blank">Samsung’s external pack (AA-PL1UC8B)</a> which I doubt is even manufactured anymore. </li>            <li><a href="http://www.bixnet.com/cntc2.html" target="_blank">This is the exact spec on the DC-in power tip dimensions</a> … it does come with the BP150 </li>            <li><a href="http://www.buy-laptop-battery.org/external-universal-laptop-battery.htm" target="_blank">Cheaper ($120’ish) Toshiba unit with half the horses (74Wh)</a> – Model#: EEXT001WO1 </li>            <li><a href="http://www.batterygeek.net/Batterygeek-15-21-130-External-Laptop-Battery-p/15-21-130_batterygeek.htm" target="_blank">BatteryGeeks.net</a> has some awesome looking units but they’re pricey.. $300 for 130Wh </li>         </ul>          &#160;          I have a buddy that got the <a href="http://www.newegg.com/Product/Product.aspx?Item=N82E16855997152&amp;cm_re=tekkeon-_-55-997-152-_-Product" target="_blank">“Tekkeon myPower All” (Model#: MP3450) for $109 from NewEgg</a>… seems like a nicely flexible 50Wh battery for multiple purposes          &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160; 9 included adapter tips and selectable voltages: 5V, 6V, 7.5V, 9V, 12V, 14V, 16V, 19V          Make sure to compare currently three slightly different models MP3450 R2, MP3750 R2, MP3450i R2 (comparison tables <a href="http://www.tekkeon.com/products-mypowerall.html" target="_blank">here</a> and <a href="http://www.tekkeon.com/products-mypall-features.html" target="_blank">here</a>), differences are very subtle… MP3450 has most selectable voltages &amp; travel charger, MP3450i is a little more beefy/expensive.          <a href="http://www.newegg.com/Product/Product.aspx?Item=N82E16855997152&amp;cm_re=tekkeon-_-55-997-152-_-Product" target="_blank"><img style="background-image: none; border-right-width: 0px; padding-left: 0px; padding-right: 0px; display: inline; border-top-width: 0px; border-bottom-width: 0px; border-left-width: 0px; padding-top: 0px" title="Untitled" border="0" alt="Untitled" src="http://lh5.ggpht.com/_XlySlDLkdOc/TXZPwsG4JSI/AAAAAAAAE5g/DbY5MdbvdB8/Untitled%5B4%5D.png?imgmax=800" width="240" height="170" /></a>       </td>     </tr>      <tr>       <td>         AverMedia QuickPlay          PC VGA to TV          <a href="http://www.avermedia-usa.com/presentation/product_quickplay.asp"><img style="border-right-width: 0px; display: inline; border-top-width: 0px; border-bottom-width: 0px; border-left-width: 0px" title="image" border="0" alt="image" src="http://lh5.ggpht.com/_XlySlDLkdOc/TIZ17iZkhEI/AAAAAAAAEwQ/ifd8aHwYOMI/image%5B5%5D.png?imgmax=800" width="208" height="204" /></a>        </td>        <td valign="top">Results vary wildly on this since it depends on which signal format you’re able to go with… single composite video is not so hot… but “YPbPr” composite has turned out very crisp for me on a recent display.&#160;&#160; If you’re ready to carry a bunch of cables and be happy that you have a connection at all, this unit is “ok” for <a href="http://www.google.com/products/catalog?hl=en&amp;q=avermedia+quickplay&amp;cid=2525492441776978560&amp;sa=button#scoring=p" target="_blank">$70 street price</a>… that’s a little steep for what you get out of this so don’t go any higher.</td>     </tr>      <tr>       <td>         Bluetooth Keyboard              <br />Sierra model by ThinkOutside (discontinued)          <a href="http://jkontherun.blogs.com/jkontherun/2006/09/thinkoutside_si.html" target="_blank"><img style="border-right-width: 0px; display: inline; border-top-width: 0px; border-bottom-width: 0px; border-left-width: 0px" title="sierra1[1]" border="0" alt="sierra1[1]" src="http://lh5.ggpht.com/_XlySlDLkdOc/Sqi14YO7SOI/AAAAAAAAEwY/ZPKLdbc1ZGc/sierra11%5B1%5D.jpg?imgmax=800" width="240" height="179" /></a>        </td>        <td valign="top"><a href="http://jkontherun.blogs.com/jkontherun/2006/09/thinkoutside_si.html">This BlueTooth keyboard is pretty nifty</a>... actually managed to get my hands on one from eBay for $65 ... it looks like some idiots acquired that company and nixed the whole keyboard product line so they're no longer manufactured... it does have a good feel and the case is slick.&#160; <br />          <br />Naturally something this small can’t be very sturdy… I’ve already lost a screw due to a weak plastic screw hole but it’s holding together ok.</td>     </tr>      <tr>       <td>         Otter Box case                    <a href="http://www.otterbox.com/samsung-q1u-p-defender-case" target="_blank"><img style="border-right-width: 0px; display: inline; border-top-width: 0px; border-bottom-width: 0px; border-left-width: 0px" title="OtterBox" border="0" alt="OtterBox" src="http://lh6.ggpht.com/_XlySlDLkdOc/Sqi145EKcNI/AAAAAAAAEkw/GuIA9J2YsaQ/OtterBox%5B14%5D.png?imgmax=800" width="240" height="175" /></a>        </td>        <td>This protective case by <a href="http://www.otterbox.com/pc-tablet-umpc-cases/samsung-q1up-case/">&quot;Otter Box&quot; </a>looks pretty sweet in the ads but after having it for a while <u>I don’t really recommend it</u>.           <br />It’s not a very polished product.           <br />I’ve logged a years worth of hiking and biking miles on this Samsung now and I never take the Otter Box.           <br />Just get a couple screen protectors since that’s really all that needs protecting.           <br />I do wish RAM-Mounts made an “Aqua Box” that was large enough for a full waterproof solution (<a title="http://www.gpscity.com/aqua-box-mount" href="http://www.gpscity.com/aqua-box-mount">http://www.gpscity.com/aqua-box-mount</a>).           <br />          <br />They had to make it generic enough to handle a couple different units with different features.           <br />It winds up being a clumsy mix of rubber hole covers at various points around the main plastic case.           <br />The plastic part is two pieces that snap together around the tablet (front and back) with typical &quot;pressure clips&quot;, 2 on top and 2 on bottom/           <br />Those clips held up just fine under the jostling of a hike... kinda worried about wearing them down taking the tablet in &amp; out between hikes.           <br />The rubber feels hardy… it covers the back almost entirely... <u>I wish the whole thing was made of that thick rubber and no plastic!</u>           <br />          <br />I'd say the biggest disappointment is the thick flexible clear plastic cover for the tablet screen and side buttons.           <br />It really isn’t that good of a fit which makes using those little keyboard buttons even tougher so the onscreen &quot;dialkeys&quot; software keyboard is even more necessary.           <br />          <br />One bummer is that&#160; you can’t leave the case on and still use the charging cradle.           <br />Taking it on and off isn’t the speediest process.           <br />          <br />It comes with a hand strap that can be mounted on either left or right hand side with allen screw holes that might come in handy for other mounting scenarios.           <br />          <br />It does add about 12 ounces.</td>     </tr>   </tbody></table>  <br />  <br />Misc Links:   <ul>   <li><a href="http://www.tabletpcreview.com/default.asp?newsID=1070">Showing Ubuntu loaded up</a> </li>    <li><a href="http://shop.vendio.com/malibu281/item/996351118/index.html">Cheapest vendor I've found</a> for the Q1U’s </li>    <li><a href="http://ubertablet.blogspot.com/2007/06/how-to-upgrade-q1-ultra-to-2gb-ram.html">How to get the bugger open for upgrades (RAM, etc.)</a> </li>    <li><a href="http://jkontherun.blogs.com/">jkontherun.blogs.com</a> - tons of good hands on mobile hardware info including the Samsungs </li> </ul>  <br />Reviews:   <br />  <ul>   <li><a href="http://www.mobiletechreview.com/notebooks/Samsung-Q1-Ultra.htm">Mobile Tech Review</a> </li> </ul>  <br />Nifty:   <br />  <ul>   <li>When it's just sitting there in its charging cradle, throw on Google Photo Screensaver and it doubles as one of those nifty wireless photo picture frame screens that are all the rage these days ;-) </li>    <li>It's naturally a great mp3/avi player for planes, etc... Remember to take headset(s) and a Y-splitter if there's a better half in your equation </li>    <li>During trips, at end of day, it's nice to empty out one's digicam chip and review photos on the tablet's larger screen </li> </ul>

 [1]: http://lh6.ggpht.com/_XlySlDLkdOc/SXYXrC3LnVI/AAAAAAAACrk/cblrtazebPM/s1600-h/Snap1%5B6%5D.jpg
 [2]: http://www.samsung.com/us/system/consumer/product/2008/04/29/np_q1ua000sea/Q1Ultra_DataSheet_080907.pdf