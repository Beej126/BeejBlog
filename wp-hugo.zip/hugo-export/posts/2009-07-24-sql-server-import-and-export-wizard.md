---
title: SQL Server Import and Export Wizard with MSDE2000 (aka DTSWizard)
author: Beej
type: post
date: 2009-07-24T12:27:00+00:00
url: /2009/07/sql-server-import-and-export-wizard.html
blogger_bid:
  - 7726907200224433699
blogger_blog:
  - www.beejblog.com
blogger_id:
  - 1807409144874306626
blogger_author:
  - g108669953529091704409
blogger_permalink:
  - /2009/07/sql-server-import-and-export-wizard.html
dsq_thread_id:
  - 5691426793
tags:
  - Database

---
  * It does work 
  * It comes bundled with “Microsoft SQL Server 2005 Express Edition Toolkit” &#8211; <a href="http://www.microsoft.com/downloads/details.aspx?familyid=D434DC36-A24D-44EE-937E-553C382557E3&displaylang=en" target="_blank">Service Pack 3</a>**** appears to be the latest (12/15/2008)
  * Make sure you click off to install all the subcomponents, DTSWizard was inside of one of them… not sure which yet

  * Depending on what you already have installed the installs might prompt you to install various components found here <a href="http://www.microsoft.com/downloads/details.aspx?FamilyId=50b97994-8453-4998-8226-fa42ec403d17&DisplayLang=en" target="_blank">Feature Pack for Microsoft SQL Server 2005 &#8211; February 2007</a> 
  * fyi, <a href="http://www.microsoft.com/downloads/details.aspx?FamilyId=56E5B1C5-BF17-42E0-A410-371A838E570A&displaylang=en" target="_blank">Microsoft SQL Server Database Publishing Wizard 1.1</a> only exports to destinations configured for this specific web service based transfer