---
title: iTunesControl
author: Beej
type: post
date: 2010-10-23T09:46:00+00:00
url: /2010/10/itunescontro.html
blogger_bid:
  - 7726907200224433699
blogger_blog:
  - www.beejblog.com
blogger_id:
  - 1684033210048946624
blogger_author:
  - g108669953529091704409
blogger_permalink:
  - /2010/10/itunescontrol.html
blogger_thumbnail:
  - http://lh5.ggpht.com/_XlySlDLkdOc/TMKu5wqLbnI/AAAAAAAAE0o/YvyM0guh-FQ/image_thumb%5B16%5D.png?imgmax=800
snapEdIT:
  - 1
snapTW:
  - |
    s:199:"a:1:{i:0;a:7:{s:2:"do";s:1:"1";s:9:"msgFormat";s:27:"%TITLE%
    %URL%
    
    %EXCERPT%";s:8:"attchImg";s:1:"1";s:9:"isAutoImg";s:1:"A";s:8:"imgToUse";s:0:"";s:9:"isAutoURL";s:1:"A";s:8:"urlToUse";s:0:"";}}";
dsq_thread_id:
  - 5542151734
categories:
  - Uncategorized
tags:
  - Music

---
<a href="http://itunescontrol.com/" target="_blank">This thing totally rocks</a>!… essentially flawless implementation of global hotkeys plugin to control iTunes and also sweet configurable heads-up-display functionality (example shot below)… if you’ve been looking for this kind of functionality, look no further! (waaaay more functional than the clunky Aqua-Soft mmKeys.dll plugin that’s out there) Super bonus points: the developer Carson Morrow is a great guy… very responsive! [<img style="background-image: none; border-bottom: 0px; border-left: 0px; padding-left: 0px; padding-right: 0px; display: inline; border-top: 0px; border-right: 0px; padding-top: 0px" title="image" border="0" alt="image" src="http://lh5.ggpht.com/_XlySlDLkdOc/TMKu5wqLbnI/AAAAAAAAE0o/YvyM0guh-FQ/image_thumb%5B16%5D.png?imgmax=800" width="773" height="504" />][1]

 [1]: http://lh3.ggpht.com/_XlySlDLkdOc/TMKu4kEyHnI/AAAAAAAAE0k/ZJgboBFngBA/s1600-h/image%5B26%5D.png