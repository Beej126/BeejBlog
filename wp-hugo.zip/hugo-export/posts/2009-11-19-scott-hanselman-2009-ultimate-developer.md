---
title: "Scott Hanselman's 2009 Ultimate Developer and Power Users Tool List for Windows"
author: Beej
type: post
date: 2009-11-20T01:17:00+00:00
url: /2009/11/scott-hanselman-2009-ultimate-developer.html
blogger_bid:
  - 7726907200224433699
blogger_blog:
  - www.beejblog.com
blogger_id:
  - 2362046131339157290
blogger_author:
  - g108669953529091704409
blogger_permalink:
  - /2009/11/scott-hanselman-2009-ultimate-developer.html
dsq_thread_id:
  - 5863855670
categories:
  - Uncategorized
tags:
  - Software

---
#### [Scott Hanselman&#8217;s 2009 Ultimate Developer and Power Users Tool List for Windows][1]

Just too dang good to relegate to a simple Delicious bookmark !

 [1]: http://www.hanselman.com/blog/ScottHanselmans2009UltimateDeveloperAndPowerUsersToolListForWindows.aspx