---
title: My Current Favorite 2.5” Drive + Enclosure
author: Beej
type: post
date: 2009-04-17T00:23:00+00:00
url: /2009/04/my-current-favorite-25-drive-enclosure.html
blogger_bid:
  - 7726907200224433699
blogger_blog:
  - www.beejblog.com
blogger_id:
  - 5966242277938029357
blogger_author:
  - g108669953529091704409
blogger_comments:
  - 1
blogger_permalink:
  - /2009/04/my-current-favorite-25-drive-enclosure.html
blogger_thumbnail:
  - http://www.coolmaxusa.com/computerS/enlarge/HD-250L_2.jpg
dsq_thread_id:
  - 5508631557
snapEdIT:
  - 1
snapTW:
  - |
    s:199:"a:1:{i:0;a:7:{s:2:"do";s:1:"1";s:9:"msgFormat";s:27:"%TITLE%
    %URL%
    
    %EXCERPT%";s:8:"attchImg";s:1:"1";s:9:"isAutoImg";s:1:"A";s:8:"imgToUse";s:0:"";s:9:"isAutoURL";s:1:"A";s:8:"urlToUse";s:0:"";}}";
categories:
  - Uncategorized
tags:
  - Hardware

---
Drive:

  * <a title="TigerDirect" href="http://www.seagate.com/ww/v/index.jsp?locale=en-US&name=st9500420asg-momentus-7200.4-sata-gf-500-gb-hd&vgnextoid=3a07bfafecadd110VgnVCM100000f5ee0a0aRCRD&vgnextchannel=819a2c74f15dd110VgnVCM100000f5ee0a0aRCRD&reqPage=Model" target="_blank">Seagate Momentus 7200.4 G</a> (Model#: **ST9500420ASG**; note**:** ‘G’ = Shock Protection, there’s a ST9500420AS, sans “G” as well) 
  * <a href="http://www.provantage.com/seagate-st9500420asg~7SEGS1VJ.htm" target="_blank">$120 @ ProVantage</a> 
  * 500GB ! 
  * 7200RPM 
  * 16MB Buffer 
  * 3.0GB/s SATA-II 

Enclosure:

  * <a href="http://www.coolmaxusa.com/productDetails.asp?item=HD-250L-eSATA&details=overview&subcategory=eSATA&category=2.5SATA" target="_blank">CoolMax HD-250L-eSATA</a> 
  * TigerDirect = <a title="TigerDirect.com Product Detail" href="http://www.tigerdirect.com/applications/SearchTools/item-details.asp?EdpNo=3603274&sku=T13-1082" target="_blank">$25</a> 
  * It’s leather so it hides greasy fingerprints very nicely compared to other hard shells 
  * The cables are a bit long & bulky compared to the nice little ones that come with say the WD Passport… but the outer case has a nice little pocket that keeps them in check. 

> <a title="CoolMax Product Detail" href="http://coolmaxusa.com/productDetails.asp?item=HD-250L-eSATA&details=overview&subcategory=eSATA&category=2.5SATA" target="_blank"><img alt="HD-250L-eSATA" align="center" src="http://www.coolmaxusa.com/computerS/enlarge/HD-250L_2.jpg" /></a><a href="http://coolmaxusa.com/productDetails.asp?item=HD-250L-eSATA&details=faq&subcategory=eSATA&category=2.5SATA" target="_blank"><img style="border-right-width: 0px; display: inline; border-top-width: 0px; border-bottom-width: 0px; border-left-width: 0px" title="image" border="0" alt="image" src="http://lh3.ggpht.com/_XlySlDLkdOc/ShwVsRR9ugI/AAAAAAAADRE/akF7B7jgdFw/image%5B6%5D.png?imgmax=800" width="244" height="139" /></a> <a href="http://coolmaxusa.com/productDetails.asp?item=HD-250L-eSATA&details=faq&subcategory=eSATA&category=2.5SATA" target="_blank"><img style="border-right-width: 0px; display: inline; border-top-width: 0px; border-bottom-width: 0px; border-left-width: 0px" title="image" border="0" alt="image" src="http://lh5.ggpht.com/_XlySlDLkdOc/ShwVsye16EI/AAAAAAAADRI/CFZefjewN68/image%5B7%5D.png?imgmax=800" width="244" height="122" /></a> 

&#160; Previous Fave&#8217;:

  * <a href="http://www.wdc.com/en/products/products.asp?driveid=477" target="_blank">Western Digital Scorpio “Black” with <strong>Free Fall Sensor</strong></a> (Model#: WD3200BJKT) 
  * ~<a href="http://www.google.com/products/catalog?hl=en&q=WD3200BJKT&cid=13330041035018023775&scoring=p#ps-sellers" target="_blank">$80 street</a> 
  * 320GB 
  * 7200 RPM 
  * 16MB Buffer&#160;&#160; 
  * the so called ‘Black’ series = 7200 RPM 
  * ‘Blue’ series = 5400 
  * 320GB is currently WD’s largest capacity 
  * Only models with the "J" in the model have the "Free Fall Sensor"