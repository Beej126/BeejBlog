---
title: Weather Wallpaper
author: Beej
type: post
date: 2017-03-10T00:11:37+00:00
url: /2017/03/weather-desk.html
snap_isAutoPosted:
  - 1
dsq_thread_id:
  - 5620359327
snapEdIT:
  - 1
snapTW:
  - |
    s:397:"a:1:{i:0;a:12:{s:2:"do";s:1:"1";s:9:"timeToRun";s:0:"";s:9:"msgFormat";s:27:"%TITLE%
    %URL%
    
    %EXCERPT%";s:8:"attchImg";s:1:"1";s:9:"isAutoImg";s:1:"A";s:8:"imgToUse";s:0:"";s:9:"isAutoURL";s:1:"A";s:8:"urlToUse";s:0:"";s:8:"isPosted";s:1:"1";s:4:"pgID";s:18:"839992174452252672";s:7:"postURL";s:53:"https://twitter.com/BeejSEA/status/839992174452252672";s:5:"pDate";s:19:"2017-03-10 00:11:58";}}";
categories:
  - Uncategorized
tags:
  - NodeJS

---
