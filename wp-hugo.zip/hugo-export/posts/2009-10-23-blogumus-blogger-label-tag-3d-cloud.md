---
title: “Blogumus” – Blogger Label Tag 3D Cloud Widget
author: Beej
type: post
date: 2009-10-23T19:40:00+00:00
url: /2009/10/blogumus-blogger-label-tag-3d-cloud.html
blogger_bid:
  - 7726907200224433699
blogger_blog:
  - www.beejblog.com
blogger_id:
  - 2552258595813898393
blogger_author:
  - g108669953529091704409
blogger_permalink:
  - /2009/10/blogumus-blogger-label-tag-3d-cloud.html
blogger_thumbnail:
  - http://lh6.ggpht.com/_XlySlDLkdOc/SuIGnNibyEI/AAAAAAAAEl8/I1wMNidc75w/Test%5B3%5D.gif?imgmax=800
dsq_thread_id:
  - 5546277571
snapEdIT:
  - 1
snapTW:
  - |
    s:199:"a:1:{i:0;a:7:{s:2:"do";s:1:"1";s:9:"msgFormat";s:27:"%TITLE%
    %URL%
    
    %EXCERPT%";s:8:"attchImg";s:1:"1";s:9:"isAutoImg";s:1:"A";s:8:"imgToUse";s:0:"";s:9:"isAutoURL";s:1:"A";s:8:"urlToUse";s:0:"";}}";
categories:
  - Uncategorized
tags:
  - Blogging

---
### [much better contemporary alternative][1]

 [1]: /?p=488