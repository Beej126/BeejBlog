---
title: My Pick for USB to SATA/IDE (2.5”/3.5”) Adaptor
author: Beej
type: post
date: 2009-05-22T08:27:00+00:00
url: /2009/05/my-pick-for-usb-to-sataide-2535-adaptor.html
blogger_bid:
  - 7726907200224433699
blogger_blog:
  - www.beejblog.com
blogger_id:
  - 1999906619629253033
blogger_author:
  - g108669953529091704409
blogger_permalink:
  - /2009/05/my-pick-for-usb-to-sataide-2535-adaptor.html
blogger_thumbnail:
  - http://lh6.ggpht.com/_XlySlDLkdOc/ShZh6WC2ghI/AAAAAAAADQ8/Bjis50QdSsU/image%5B12%5D.png?imgmax=800
snapEdIT:
  - 1
snapTW:
  - |
    s:199:"a:1:{i:0;a:7:{s:2:"do";s:1:"1";s:9:"msgFormat";s:27:"%TITLE%
    %URL%
    
    %EXCERPT%";s:8:"attchImg";s:1:"1";s:9:"isAutoImg";s:1:"A";s:8:"imgToUse";s:0:"";s:9:"isAutoURL";s:1:"A";s:8:"urlToUse";s:0:"";}}";
dsq_thread_id:
  - 5753669545
categories:
  - Uncategorized
tags:
  - Hardware

---
Highlights:

  * <a href="http://www.tigerdirect.com/applications/SearchTools/item-details.asp?EdpNo=2329300&sku=M501-1220" target="_blank">Sabrent Brand, Model: USB-DSC5</a> &#8211; $20
  * 2A Power Supply.&#160; I read that at least one other brand, KingWin maybe, only had a 100mA! feed… and that guy was finding that it wasn’t enough juice for a 3.5”er
  * All the cables/adapters you need… SATA power, SATA Data, gee wonder what that real small one 2nd from the left is for??
  * Normal 3 prong PC style power cable… other brands had the fairly standard 2 prong laptop cable which you might find preferable… I live in Germany and it’s easier for me to find the German style wall plug with the 3 prong cables.

As an aside, I’m swinging back to TigerDirect rather than NewEgg for a while… Tiger really screwed some things up for me at their local stores in Chicago so i was carrying a grudge… but i tend to think their mailorder business has always been decent… NewEgg really jacks you on the APO shipping… i’m such a fickle filly. (NewEgg does tend to have better product images though, so this links to Tiger but image was pulled from NewEgg 🙂 <a title="Tiger" href="http://www.tigerdirect.com/applications/SearchTools/item-details.asp?EdpNo=2329300&sku=M501-1220" target="_blank"><img style="border-bottom: 0px; border-left: 0px; display: inline; border-top: 0px; border-right: 0px" title="image" border="0" alt="image" src="http://lh6.ggpht.com/_XlySlDLkdOc/ShZh6WC2ghI/AAAAAAAADQ8/Bjis50QdSsU/image%5B12%5D.png?imgmax=800" width="368" height="280" /></a> This “Newer Technology” model looks a little “slicker” but is it really worth $10 more? [<img style="border-bottom: 0px; border-left: 0px; display: inline; border-top: 0px; border-right: 0px" title="image" border="0" alt="image" src="http://lh3.ggpht.com/_XlySlDLkdOc/ShZk_OQAXvI/AAAAAAAADRA/pydDCsOfzwM/image%5B17%5D.png?imgmax=800" width="306" height="213" />][1]

 [1]: http://eshop.macsales.com/item/Newer%20Technology/U2NV2SPATA/ "OWC.com"