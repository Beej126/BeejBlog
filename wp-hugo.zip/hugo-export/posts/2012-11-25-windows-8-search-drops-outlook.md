---
title: Windows 8 Search Drops Outlook :(
author: Beej
type: post
date: 2012-11-26T01:14:00+00:00
url: /2012/11/windows-8-search-drops-outlook.html
blogger_bid:
  - 7726907200224433699
blogger_blog:
  - www.beejblog.com
blogger_id:
  - 4286407114359335090
blogger_author:
  - g108669953529091704409
blogger_permalink:
  - /2012/11/windows-8-search-drops-outlook.html
categories:
  - Uncategorized
tags:
  - Windows 8+

---
Nutshell:

  * Windows 8 Metro search doesn’t include Outlook indexed items at all.
  * Windows 8 Explorer can be told to search Outlook items but only with Outlook 2010 (or older).
  * If you want to search Outlook 2013 in Win8, you must use Outlook 2013’s search.

References:

  * <a href="http://www.slipstick.com/how-to-outlook/searching-outlook-in-windows-8/" target="_blank" title="http://www.slipstick.com/how-to-outlook/searching-outlook-in-windows-8/">slipstick.com</a>
  * <a href="http://www.outlook-tips.net/tips/tip-1039-searching-outlook-windows-8/" target="_blank">outlook-tips.net</a>
  * <a href="http://answers.microsoft.com/en-us/office/forum/office_2010-outlook/outlook-pst-files-not-being-indexed-in-windows-8/6b5a3934-6850-4eaa-8d02-e21ec7473f52?msgId=2781c8a0-3208-46ad-bb4c-627b34f63969&page=2" target="_blank" title="http://answers.microsoft.com">answers.microsoft.com</a>