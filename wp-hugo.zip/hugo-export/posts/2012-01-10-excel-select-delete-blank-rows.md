---
title: Excel – Select (Delete) Blank Rows
author: Beej
type: post
date: 2012-01-10T19:59:00+00:00
url: /2012/01/excel-select-delete-blank-rows.html
blogger_bid:
  - 7726907200224433699
blogger_blog:
  - www.beejblog.com
blogger_id:
  - 6025445994271258721
blogger_author:
  - g108669953529091704409
blogger_permalink:
  - /2012/01/excel-select-delete-blank-rows.html
tags:
  - Productivity

---
From here: [http://www.theexceladdict.com/_t/t031008.htm][1] Reflecting Microsoft’s current button naming in Excel 2010… 

  * Select a column possessing representative blanks, from top to bottom.
  * F5.
  * “Special…” button &#8211; here&#8217;s where the magic happens&#8230; 
  * “Blanks” radio button.
  * “Delete” ribbon button/menu (under Home tab) – “delete sheet rows” menu item.

 [1]: http://www.theexceladdict.com/_t/t031008.htm "http://www.theexceladdict.com/_t/t031008.htm"