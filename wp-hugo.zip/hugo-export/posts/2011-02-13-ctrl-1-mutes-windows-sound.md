---
title: CTRL, 1 – Mutes Windows Sound?!?!
author: Beej
type: post
date: 2011-02-13T12:00:00+00:00
url: /2011/02/ctrl-1-mutes-windows-sound.html
blogger_bid:
  - 7726907200224433699
blogger_blog:
  - www.beejblog.com
blogger_id:
  - 3309113062562807929
blogger_author:
  - g108669953529091704409
blogger_permalink:
  - /2011/02/ctrl-1-mutes-windows-sound.html
dsq_thread_id:
  - 5626191750
tags:
  - Music
  - SysAdmin

---
Is this a standard???&#160; I can’t find reference to this hot key sequence out there in Google land. You need to hit CTRL, release and then hit 1, not CTRL-1, i.e don’t hold down CTRL. On my (\*non\* Windows Media Keys Keyboard under Windows 7) system here, it works with both left and right CTRL and main keyboard or numeric keyboard “1”. &#160; Google Keywords: Windows 7, Audio, Mute, Volume, Control, CTRL, 1, One